﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI; 
using UnityEngine;

public class Imageflicker : MonoBehaviour {

	private bool goingUpUpUpUpUp = true;

	public float feedspped = 0.05f;
	public float transparency;
	private Image star;

	private Color bla = new Color (1, 1, 1, 1);

	// Use this for initialization
	void Start () {
		star = GetComponent<Image> ();
	}

	// Update is called once per frame
	void Update () {
		if (star.color.a < transparency) {
			goingUpUpUpUpUp = false;
		} else if (star.color.a > 0.98f) {
			goingUpUpUpUpUp = true;
		}

		if (!goingUpUpUpUpUp) {
			bla.a = Mathf.Lerp (bla.a, 1, feedspped);
		} else {
			bla.a = Mathf.Lerp (bla.a, 0, feedspped);
		}
		star.color = bla;
	}
}
