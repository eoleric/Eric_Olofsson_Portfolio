﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera2D : MonoBehaviour {

	public Controller3D Controller;
	public GameObject Player;
	public new Camera camera;
	private int zoomDistance;
	private bool zoomedIn;
	public GameObject[] blockzones;

	private bool follow = true;

	//private float speed;
	public bool upView;

	public Vector3 target;
	public float speed = 6f;

	private bool fightBoss = false;

	public bool onlyY = false;

	public bool bossLvl = false;

	public float capY = 2.5f;

	public float capX = 2f;

	// Use this for initialization
	void Start () {
		camera = GetComponent<Camera> ();
		zoomDistance = 15;
		if (bossLvl)
			zoomDistance = 10;
		zoomedIn = true;
		//speed = Controller.MoveSpeed;
		camera.transform.position = new Vector3 (Player.transform.position.x, Player.transform.position.y, Player.transform.position.z - zoomDistance);
		Controller = Player.GetComponent<Controller3D> ();
		target = Player.transform.position - new Vector3(0f,0f, zoomDistance);

		//follow = false;
	}

	void Update() {
		//target = Player.transform.position - new Vector3(0f,0f, zoomDistance);
		if (follow) {
			moveCameraX ();
			moveCameraY ();
		} else if (onlyY) {
			moveCameraY ();
		}
		transform.position = Vector3.Lerp (transform.position, target, speed * Time.deltaTime);
		
		upView = Controller.topSide; 

		if (Input.GetButtonDown ("Zoom") && !fightBoss) {
			ZoomInOrOut ();
		}
	}

	public void moveCameraX(){

		if (Player.transform.position.x > camera.transform.position.x + capX) {
			//camera.transform.position = new Vector3 (Player.transform.position.x -2, camera.transform.position.y, camera.transform.position.z); //+= new Vector3 (speed * Time.deltaTime, 0.0f, 0.0f);
			target = new Vector3 (Player.transform.position.x -capX, target.y, target.z);
		} else if (Player.transform.position.x < camera.transform.position.x - capX) {
			//camera.transform.position = new Vector3 (Player.transform.position.x +2, camera.transform.position.y, camera.transform.position.z);//-= new Vector3 (speed * Time.deltaTime, 0.0f, 0.0f);
			target = new Vector3 (Player.transform.position.x +capX, target.y, target.z);

		}
	}

	public void moveCameraY(){
		if (Player.transform.position.y > camera.transform.position.y + capY) {
			target = new Vector3 (target.x, Player.transform.position.y - capY, target.z);
			//camera.transform.position = new Vector3 (camera.transform.position.x, Player.transform.position.y - 1.5f, camera.transform.position.z); //+= new Vector3 (0.0f, speed * Time.deltaTime, 0.0f);
		} else if (Player.transform.position.y < camera.transform.position.y - capY) {
			target = new Vector3 (target.x, Player.transform.position.y + capY, target.z);
			//camera.transform.position = new Vector3 (camera.transform.position.x, Player.transform.position.y + 1.5f, camera.transform.position.z);//-= new Vector3 (0.0f, speed * Time.deltaTime, 0.0f);
		} 
	}

	public float getRightY(bool topSide) {
		float y = 0;
		if (topSide) {
			y = 2f;
			return y;
		}
		else {
			y = -2f;
			return y;
		}
	}
		
	public void setUpView(bool topSide){
		if (topSide) {
			transform.Translate (0.0f, 3, 0.0f);
			Debug.Log ("upp");
		} else {
			transform.Translate (0.0f, -3, 0.0f);
			Debug.Log ("ner");
		}
	}
		
	public void flipCamera(bool upSide){

		if (upSide) {	
			camera.transform.RotateAround (Player.transform.position, Vector3.right, 30f);
		} else {
			camera.transform.RotateAround (Player.transform.position, Vector3.right, -30f);
		}
	}


	public void ZoomInOrOut(){
		if (zoomedIn) {
			Player.GetComponent<Controller3D> ().BOXMODEACTIVATE (true);
			zoomDistance = 30;
			zoomedIn = false;
			target = target - new Vector3(0f,0f, 15);

			//transform.Translate (0f, 0f, -15);
		} else {
			Player.GetComponent<Controller3D> ().BOXMODEACTIVATE (false);
			zoomDistance = 15;
			zoomedIn = true;
			target = target - new Vector3(0f,0f, -15);
			//transform.Translate (0f, 0f, 15f);
		}
	}

	public void ZoomInOrOut2(){
		//Debug.Log ("zoom");
		if (zoomedIn) {
			follow = false;
			zoomDistance = 25;
			zoomedIn = false;
			//StartCoroutine ("moveTo", new Vector3 (65f, 0f, -30));
			//transform.position = new Vector3 (65f, 0f, -40);
			target = new Vector3 (65f, 0f, -40);
		} else {
			follow = true;
			zoomDistance = 15;
			zoomedIn = true;
			//StartCoroutine ("moveTo", new Vector3 (Player.transform.position.x, Player.transform.position.y, Player.transform.position.z - 15f));
			//transform.position = new Vector3 (Player.transform.position.x, Player.transform.position.y, Player.transform.position.z - 15f);
			target = Player.transform.position - new Vector3(0f,0f, zoomDistance);
		}	
	}

	public IEnumerator moveTo(Vector3 goal){
		while(Vector3.Distance(transform.position, goal) > 0.5f){
			transform.position = Vector3.MoveTowards (transform.position, goal, 0.1f);
			if (Player.transform.position.x < transform.position.x + 2 && Player.transform.position.x > transform.position.x - 2)
				//follow = true;
			yield return new WaitForSeconds (Time.deltaTime);
		}
	}

	public void ResetCamera(){
		zoomDistance = 15;
		zoomedIn = true;
		target = Player.transform.position - new Vector3(0f,0f, zoomDistance);
	}

	public void LockCamToPoint(Vector3 point){
		//follow = false;
		//transform.position = point;
		zoomDistance = 30;
		zoomedIn = false;
		target = target - new Vector3(0f,0f, 10);
		foreach (GameObject g in blockzones) {
			g.SetActive (true);
		}
		fightBoss = true;
	}

	public void UnlockCam(){
		foreach (GameObject g in blockzones) {
			g.SetActive (false);
		}
		//follow = true;
		zoomDistance = 15;
		zoomedIn = true;
		target = Player.transform.position - new Vector3(0f,0f, zoomDistance);
		fightBoss = false;
	}

	public void SetOnlyY(){
		target.x = 5f;
		follow = !follow;
		onlyY = !onlyY;
	}
}
