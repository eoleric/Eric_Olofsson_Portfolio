﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera3D : MonoBehaviour {

	//public Camera camera; 
	public Controller3D player;
	public float movSpeed = 5;
	public float turnSpeed = 2;
	private Vector3 camDistance;
	private bool topside;
	//private bool startSide;

	private GameObject lastHidden;
    private GameObject obstacle;
	public Material hiddenMaterial;
	public Material visibleMaterial;

    private Renderer ren;

	// Use this for initialization
	void Start () {
		topside = player.topSide;
		//startSide = player.topSide;
	}
	
	// Update is called once per frame
	void Update () {
		topside = player.topSide;
		CheckBlockingObstacle ();
	}

	void LateUpdate(){
		transform.LookAt(player.transform.position);
	}

	public void Flip(){
		if (topside) {
			transform.localPosition = new Vector3(0f, -6f, -11f);
		} else {
			transform.localPosition = new Vector3(0f, 6f, -11f);
		}
	}

	public void CheckBlockingObstacle(){
		RaycastHit hit; 
		//float distanceToPlayer = transform.position.x - player.transform.position.x + 10;
		Vector3 playerDirection = (transform.position - player.transform.position).normalized;

		if (Physics.Raycast(transform.position, Vector3.forward, out hit, 1)) {
            if(lastHidden != null)
            {
                lastHidden.GetComponent<Renderer>().material = visibleMaterial;
            }
            obstacle = hit.collider.gameObject;
            ren = obstacle.GetComponent<Renderer>();
            visibleMaterial = ren.material;
            ren.material = hiddenMaterial;
            lastHidden = obstacle;
        }
        else
        {
            if(lastHidden != null)
            {
                ren.material = visibleMaterial;
                lastHidden = null;
            }
        }
	}
}
