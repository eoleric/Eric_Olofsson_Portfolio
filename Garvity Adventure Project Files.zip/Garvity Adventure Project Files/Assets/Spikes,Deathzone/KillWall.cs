﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillWall : MonoBehaviour {



	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void onTriggerEnter (Collider other){
		if (other.tag == "Player"){
			other.GetComponent<Controller3D> ().Die ();
			Debug.Log ("Death");

		}
	}
}
