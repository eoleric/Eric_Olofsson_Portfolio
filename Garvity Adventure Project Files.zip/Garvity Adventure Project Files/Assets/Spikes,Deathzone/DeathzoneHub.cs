﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathzoneHub : MonoBehaviour {


	public GameObject player;
	public Vector3 startpos;

	// Use this for initialization
	void Start () {
		startpos = player.GetComponent<Controller3D> ().startPos;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void DieZone(){
		transform.position = startpos;
	}
}
