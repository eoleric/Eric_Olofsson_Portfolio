﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathWall : MonoBehaviour {

	public float rotationSpeed = 20f;
	private GameObject deathWall;
	//private Rigidbody rb;

	// Use this for initialization
	void Start () {
		deathWall = gameObject;
		//rb = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void Update () {
		deathWall.transform.Rotate (new Vector3 (0, rotationSpeed, 0) * Time.deltaTime);
		
	}

	void OnTriggerEnter (Collider other){
		if (other.tag == "Player") {
			other.GetComponent<Controller3D> ().Die ();
		}
	}
}
