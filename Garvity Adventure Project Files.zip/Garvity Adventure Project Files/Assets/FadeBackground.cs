﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class FadeBackground : MonoBehaviour {

    public int InDelay;
    public int OutDelay;
    public bool fadeIn;
    public bool fadeOut;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (fadeIn)
        {
            StartCoroutine("FadeInImage");
        }
        else if(fadeOut)
        {
            StartCoroutine("FadeOutImage");
        }
    }

    IEnumerator FadeOutImage()
    {
        yield return new WaitForSeconds(OutDelay);
        Image image = GetComponent<Image>();
        image.color = new Color(image.color.r, image.color.g, image.color.b, image.color.a - (Time.deltaTime / 15f));
        while (image.color.a > 0.0f)
        {
            image.color = new Color(image.color.r, image.color.g, image.color.b, image.color.a - (Time.deltaTime / 15f));
            yield return null;
        }
    }

    IEnumerator FadeInImage()
    {
        yield return new WaitForSeconds(InDelay);
        Image image = GetComponent<Image>();
        image.color = new Color(image.color.r, image.color.g, image.color.b, image.color.a + (Time.deltaTime / 2f));
        while (image.color.a > 1.0f)
        {
            image.color = new Color(image.color.r, image.color.g, image.color.b, image.color.a + (Time.deltaTime / 2f));
            yield return null;
        }
    }
}
