﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour {

//	public GameObject camera;

	private float playerUsedTime = 0;

	private bool playerCanUse = true;

	private float boxUsedTime = 0;

	private bool boxCanUse = true;

	private List<GameObject> thingsInPortal = new List<GameObject> ();


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Time.time - playerUsedTime > 0.4f) {
			playerCanUse = true;
		}

		if (Time.time - boxUsedTime > 0.4f) {
			boxCanUse = true;
		}
	}

	void OnTriggerEnter(Collider other){
		if (other.tag == "Player" || other.tag == "Box") {
			Controller3D playerControlle = other.gameObject.GetComponent<Controller3D> ();
			if (!thingsInPortal.Contains (other.gameObject))
				thingsInPortal.Add (other.gameObject);
			if (thingsInPortal.Count > 1) {
				if (playerControlle.topSide) {
					playerControlle.GetVelocity ().SetY (12f);
				} else {
					playerControlle.GetVelocity ().SetY (-12f);
				}

//				if (other.tag == "Player") {
//					other.gameObject.transform.parent = thingsInPortal[0].transform;
//				}
			}
		} 
	}

	void OnTriggerStay(Collider other){
		if (playerCanUse) {
			if (other.tag == "Player") {
//				Controller3D firstControlle = thingsInPortal [0].GetComponent<Controller3D> ();
				Controller3D playerControlle = other.gameObject.GetComponent<Controller3D> ();
//				int i = 0;
//				while (thingsInPortal.Count > 1 && other.transform.parent == null) {
//					other.gameObject.transform.parent = thingsInPortal[i].transform;
//					i++;
//				}

//				if(thingsInPortal.Count > 1){
////					Debug.Log (playerControlle.GetVelocity ().getVelocity());
////					Debug.Log (firstControlle.GetVelocity ().getVelocity());
////					if (playerControlle.GetVelocity ().getVelocity ().y == -20 || playerControlle.GetVelocity ().getVelocity ().y == 20 || playerControlle.GetVelocity ().getVelocity ().y == 10 || playerControlle.GetVelocity ().getVelocity ().y == -10) {
////						
////						if (playerControlle.topSide) {
////							playerControlle.GetVelocity ().SetY (-10f);
////						} else {
////							playerControlle.GetVelocity ().SetY (10f);
////						}
////					}
//					if (thingsInPortal [0] != playerControlle.gameObject) {
//						Debug.Log ("1");
//						playerControlle.GetVelocity ().SetVelocity (firstControlle.GetVelocity ().getVelocity ());
//					} else {
//						playerControlle.GetVelocity ().SetVelocity (thingsInPortal [1].GetComponent<Controller3D> ().GetVelocity ().getVelocity ());
//						Debug.Log ("2");
//					}
//				}
				if (playerControlle.topSide) {
					if (other.gameObject.transform.position.y < gameObject.transform.position.y) {
						playerControlle.SetTopSide ();
//						camera.GetComponent<Camera2D>().setUpView(other.gameObject.GetComponent<Controller3D> ().topSide);

						playerCanUse = false;
						playerUsedTime = Time.time;
						if (playerControlle.GetVelocity ().getVelocity ().y > -10f) {
							playerControlle.GetVelocity ().SetY (-12f);
						}
					}
				} else {
					if (other.gameObject.transform.position.y > gameObject.transform.position.y) {
						playerControlle.SetTopSide ();
						playerCanUse = false;
						playerUsedTime = Time.time;
						if (playerControlle.GetVelocity ().getVelocity ().y < 10f) {
							playerControlle.GetVelocity ().SetY (12f);
						}
					}
				}
//				if (other.gameObject.transform.parent != null) {
//					playerControlle.GetVelocity ().SetVelocity (other.gameObject.transform.parent.gameObject.GetComponent<Controller3D> ().GetVelocity ().getVelocity ());
//				}
				//Debug.Log (playerControlle.GetVelocity ().getVelocity());
			}
		}

		if (boxCanUse) {
			if (other.tag == "Box") {
//				Controller3D firstControlle = thingsInPortal [0].GetComponent<Controller3D> ();
//				Controller3D playerControlle = other.gameObject.GetComponent<Controller3D> ();
//
//				if(thingsInPortal.Count > 1){
//					if (thingsInPortal [0] != playerControlle.gameObject) {
//						Debug.Log (playerControlle.GetVelocity ().getVelocity());
//						playerControlle.GetVelocity ().SetVelocity (firstControlle.GetVelocity ().getVelocity ());
//					} else {
//						playerControlle.GetVelocity ().SetVelocity (thingsInPortal [1].GetComponent<Controller3D> ().GetVelocity ().getVelocity ());
//						Debug.Log (playerControlle.GetVelocity ().getVelocity());
//					}
//				}

				Controller3D boxControlle = other.gameObject.GetComponent<Controller3D> ();
				if(boxControlle.GetVelocity ().getVelocity ().y == -18 || boxControlle.GetVelocity ().getVelocity ().y == 18){
					if (gameObject.transform.position.x + 0.2f < other.gameObject.transform.position.x) {
						boxControlle.GetVelocity ().SetX (-3f);
					} else if(gameObject.transform.position.x - 0.2f > other.gameObject.transform.position.x) {
						boxControlle.GetVelocity ().SetX (3f);
					}
				}
				//om box triggas men inte har någon hastighet i y så rör den mot portalen
				if (boxControlle.topSide) {
					if (other.gameObject.transform.position.y < gameObject.transform.position.y) {
						boxControlle.SetTopSide ();
						boxCanUse = false;
						boxUsedTime = Time.time;
						if (boxControlle.GetVelocity ().getVelocity ().y > -10f) {
							boxControlle.GetVelocity ().SetY (-12f);
						}
					}
				} else {
					if (other.gameObject.transform.position.y > gameObject.transform.position.y) {
						boxControlle.SetTopSide ();
						boxCanUse = false;
						boxUsedTime = Time.time;
						if (boxControlle.GetVelocity ().getVelocity ().y < 10f) {
							boxControlle.GetVelocity ().SetY (12f);
						}
					}
				}
				//Debug.Log (boxControlle.GetVelocity ().getVelocity());
			}
		}
//		if (other.tag == "Boss") {
//			Debug.Log ("test1");
//			if(other.GetComponent<Boss>().topSide && other.GetComponent<Boss>().phase3)
//				other.gameObject.transform.Translate(Vector3.up);
//			else if (!other.GetComponent<Boss>().topSide && other.GetComponent<Boss>().phase3)
//				other.gameObject.transform.Translate(Vector3.down);
//		}
	}

	void OnTriggerExit(Collider other){
		if (other.tag == "Player" || other.tag == "Box") {
			Controller3D playerControlle = other.gameObject.GetComponent<Controller3D> ();
			thingsInPortal.Remove (other.gameObject);
			if (other.gameObject.transform.position.y > transform.position.y && playerControlle.topSide == false) {
				playerControlle.SetTopSide (true);
			} else if (other.gameObject.transform.position.y < transform.position.y && playerControlle.topSide == true) {
				playerControlle.SetTopSide (false);
			}
//			if (other.tag == "Player") {
//				other.gameObject.transform.parent = null;
//			}
		}
	}
}
