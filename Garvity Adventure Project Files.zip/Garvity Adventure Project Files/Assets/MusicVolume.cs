﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicVolume : MonoBehaviour {

	private AudioSource source;
	public AudioClip music;

	// Use this for initialization
	void Start () {

		source = GetComponent<AudioSource> ();
		source.volume = 0f;
		source.Play ();
		source.loop = true;
	



	}

	void Awake(){
		while(source.volume<0.5f){
			source.volume += Time.deltaTime/2;
		}


	}
	
	// Update is called once per frame
	void Update () {

	}
}
