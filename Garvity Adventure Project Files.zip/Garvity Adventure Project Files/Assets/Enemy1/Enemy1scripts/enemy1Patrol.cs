﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy1Patrol : enemy1State {

	private HorizontalDirectionX patrolX = HorizontalDirectionX.still;
	private HorizontalDirectionZ patrolZ = HorizontalDirectionZ.still;



	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public enemy1Patrol(string direction, GameObject enemy1): base(enemy1){
		if (direction.Equals("X")) {
			patrolX = HorizontalDirectionX.right;
		} else {
			patrolZ = HorizontalDirectionZ.away;
		}
	}

	public override string getName(){
		return "patrol";
	}

	public override Vector3 GetMovement (Vector3 position){
		if (!isAtEdge (patrolX, patrolZ, position)) {
			return new Vector3 ((int)patrolX * base.getSpeed (), 0f, (int)patrolZ * base.getSpeed ());
		} else {
			patrolX = (HorizontalDirectionX)((int)patrolX * -1);
			patrolZ = (HorizontalDirectionZ)((int)patrolZ * -1);
		}

		return Vector3.zero;
	}
}
