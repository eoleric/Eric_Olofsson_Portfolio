﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathTrigger : MonoBehaviour {

	public GameObject enemy1;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnTriggerEnter(Collider other){
		if (other.tag == "Player") {
			GameObject[] shaking = GameObject.FindGameObjectsWithTag ("Shaking");

			for(int i = 0; i < shaking.Length; i++){
				if(Vector3.Distance(shaking[i].transform.position, enemy1.transform.position) < 5f){
					shaking[i].GetComponent<GroundBehaviour> ().SetShake ();
				}
			}
			other.gameObject.GetComponent<Controller3D> ().GetVelocity ().SetY (10f);
			enemy1.GetComponent<enemy1>().Die ();
		}
	}
}
