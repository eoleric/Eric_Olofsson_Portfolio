﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy1State {

	private float rayOffset = 0.55F;
	private float rayRayOffset = 0.75F;

	private float speed = 0.018F;

	private LayerMask layer = LayerMask.GetMask("Ignore");

	public GameObject enemy1;

	public float getSpeed(){
		return speed;
	}

	public GameObject getEnemy(){
		return enemy1;
	}

	public enemy1State(GameObject enemy){
		enemy1 = enemy;
	}

	public virtual string getName(){
		return "inget";
	}

	public virtual Vector3 GetMovement (Vector3 position){
		return Vector3.zero;
	}

	public bool isAtEdge(HorizontalDirectionX horizontalDirectionX, HorizontalDirectionZ horizontalDirectionZ, Vector3 position){
		Vector3 origin = position;
		Vector3 origin2 = position;

		origin.x = origin.x + ((int)horizontalDirectionX * rayOffset);
		origin.z = origin.z + ((int)horizontalDirectionZ * rayOffset);

		origin2.x = origin2.x + ((int)horizontalDirectionX * rayRayOffset);
		origin2.z = origin2.z + ((int)horizontalDirectionZ * rayRayOffset);

		if (Physics.Raycast (origin, Vector3.down, 0.4f, layer) || Physics.Raycast (origin2, Vector3.down, 0.4f, layer)) {
			return false;
		} else {
			return true;
		}
	}
}
