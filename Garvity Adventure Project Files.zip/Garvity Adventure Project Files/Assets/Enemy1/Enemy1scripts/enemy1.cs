﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy1 : MonoBehaviour {

	public string patrol;

	private enemy1State curState;

	[SerializeField]
	private GameObject player;

	public bool topSide = true;

	private float curPosX;
	private float lastPosX;

	private float curPosZ;
	private float lastPosZ;

	public bool is2D = true;
	public AudioSource source;
	public AudioClip deathClip;

	// Use this for initialization
	void Start () {
		curState = new enemy1Idle (gameObject);
		source = GetComponent<AudioSource> ();
	}
	
	// Update is called once per frame
	void Update () {
		transform.rotation = Quaternion.Euler (0f,0f,0f);
		if(is2D)
			transform.position = new Vector3 (transform.position.x,transform.position.y,0.5f);
		if(topSide){
			gameObject.GetComponent<Rigidbody> ().AddForce (Physics.gravity * -gameObject.GetComponent<Rigidbody> ().mass);
		}else{
			gameObject.GetComponent<Rigidbody> ().AddForce (Physics.gravity * gameObject.GetComponent<Rigidbody> ().mass);
		}
		HandleMovement ();
	}

	public void Die() {
        StartCoroutine(DeathDelay());
    }

    IEnumerator DeathDelay()
    {
        source.PlayOneShot(deathClip);
        yield return new WaitForSeconds(deathClip.length);
        curState = new enemy1Defeat(gameObject);

    }

	void OnTriggerEnter(Collider other){
		if(other.tag == "Player" && (curState as enemy1Idle != null)){
			curState = new enemy1Patrol (patrol, gameObject);
		}
	}

	void OnTriggerStay(Collider other){
		if (Vector3.Distance (other.transform.position, gameObject.transform.position) < 3f) {
			if (curState as enemy1Attack == null) {
				if (other.tag == "Player") {
					curState = new enemy1Attack (other.gameObject, gameObject);
				}
			}
		} else {
			if(other.tag == "Player" && (curState as enemy1Patrol == null)){
				curState = new enemy1Patrol (patrol, gameObject);
			}
		} 
	}

	void OnTriggerExit(Collider other) {
		if(other.tag == "Player" && (curState as enemy1Idle == null)){
			curState = new enemy1Idle (gameObject);
		}
	}

	void OnCollisionEnter(Collision collision) {
		if (collision.gameObject.tag == "MovingPlatform") {
			
		}
		if (collision.gameObject.tag == "Obstacle") {
			collision.gameObject.GetComponent<GroundBehaviour> ().SetShake ();
		} else if (collision.gameObject.tag == "Player") {
			collision.gameObject.GetComponent<Controller3D> ().Die ();
		}
	}

	void OnCollisionExit(Collision collision) {
		if(collision.gameObject.tag == "Shaking"){
			collision.gameObject.GetComponent<GroundBehaviour> ().SetShake ();
		}
	}
		
	private void HandleMovement(){
		transform.Translate (curState.GetMovement (transform.position));
	}

	public void taBort(){
		curState = new enemy1Defeat (gameObject);
	}
	public void remove(){
		Destroy (gameObject);
	}
}
