﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy1Defeat : enemy1State {

	public enemy1Defeat(GameObject enemy1): base(enemy1){
		GameObject[] shaking = GameObject.FindGameObjectsWithTag ("Shaking");

		for(int i = 0; i < shaking.Length; i++){
			if(Vector3.Distance(shaking[i].transform.position, base.getEnemy().transform.position) < 5f){
				shaking[i].GetComponent<GroundBehaviour> ().SetShake ();
			}
		}
            base.getEnemy().GetComponent<enemy1>().remove();
	}

	// Use this for initialization
	void Start () {
	}

	// Update is called once per frame
	void Update () {
		
	}

	public override Vector3 GetMovement (Vector3 position){
		return Vector3.zero;
	}
}
