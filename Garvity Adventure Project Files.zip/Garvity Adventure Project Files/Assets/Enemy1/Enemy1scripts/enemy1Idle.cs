﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy1Idle : enemy1State {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public enemy1Idle(GameObject player): base(player){
		
	}

	public override string getName(){
		return "idle";
	}

	public override Vector3 GetMovement (Vector3 position){
		return Vector3.zero;
	}
}
