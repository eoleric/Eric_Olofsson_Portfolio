﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy1Attack : enemy1State {

	private HorizontalDirectionX patrolX = HorizontalDirectionX.still;
	private HorizontalDirectionZ patrolZ = HorizontalDirectionZ.still;

	private GameObject player;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public enemy1Attack(GameObject player1, GameObject enemy1): base(enemy1){
		player = player1;
	}

	public override Vector3 GetMovement (Vector3 position){
		if (0.4f + player.transform.position.x < base.getEnemy ().transform.position.x) {
			patrolX = HorizontalDirectionX.left;
		} else if (player.transform.position.x > base.getEnemy ().transform.position.x + 0.4) {
			patrolX = HorizontalDirectionX.right;
		} else {
			patrolX = HorizontalDirectionX.still;
		}

		if (0.4 + player.transform.position.z < base.getEnemy ().transform.position.z) {
			patrolZ = HorizontalDirectionZ.toward;
		} else if (player.transform.position.z > base.getEnemy ().transform.position.z + 0.4f) {
			patrolZ = HorizontalDirectionZ.away;
		} else {
			patrolZ = HorizontalDirectionZ.still;
		}

		if (!isAtEdge (patrolX, patrolZ, position)) {
			return new Vector3 ((int)patrolX * base.getSpeed (), 0f, (int)patrolZ * base.getSpeed ());
		} else {
			return Vector3.zero;
		}
	}
}
