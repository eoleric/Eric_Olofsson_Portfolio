﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundBehaviour : MonoBehaviour {

	[SerializeField]
	private bool shaking = false;
	private Vector3 startPos;
	private Vector3 shakePos;

	private Color standardColor;

	public Color damagedColor;

    //private Color32 shakingColor = new Color32(156,0,0,255);
    private Color32 shakingColor = new Color32(0, 158, 172, 255);

    private Renderer rend;

	public bool lvl3Ground = false;

//    private AudioSource source;
//    public AudioClip Shakeclip;

    private int health = 2;

	public void SetShake(){
		shaking = !shaking;
		if (shaking) {
            gameObject.tag = "Shaking";
		} else {
            gameObject.tag = "Obstacle";
		}
		transform.position = shakePos;
	}

	public void TakeDamage(){
		health -= 1;
		if (health == 1) {
			MakeDamaged ();
		} else if (health < 1) {
			StartCoroutine ("DieRoutine");
		}
	}

	// Use this for initialization
	void Start () {
		gameObject.tag = "Obstacle";
//        source = GetComponent<AudioSource>();
        rend = GetComponent<Renderer> ();
		standardColor = rend.material.color;
		startPos = transform.position;
		shakePos = transform.position;
	}


	// Update is called once per frame
	void Update () {
		if (shaking) {
//            if (!source.isPlaying)
//            {
//                source.loop = true;
//                source.clip = Shakeclip;
//                source.Play();
//            }
			rend.material.color = shakingColor;
			transform.position = shakePos;
			transform.position = new Vector3 (shakePos.x + Random.Range (-0.05f, 0.05f), shakePos.y + Random.Range (-0.05f, 0.05f), shakePos.z + Random.Range (-0.05f, 0.05f));
		} else {
            if (health == 1)
            {
                rend.material.color = damagedColor;
            }
            else if (health > 1)
            {
                rend.material.color = standardColor;
            }
		}
//        else
//        {
//            if(source.isPlaying)
//            {
//                source.Pause();
//            }
//        }
	}

	public void MakeDamaged(){
		rend.material.color = damagedColor;
	}

	IEnumerator DieRoutine(){
        transform.localPosition = startPos + new Vector3 (100f, 0f, 0f);
		shakePos = transform.position;
		yield return new WaitForSeconds (5f);
		transform.position = startPos;
		shakePos = transform.position;
		rend.material.color = standardColor;
		health = 2;
	}

	public void ShakeForTime(){
		StartCoroutine ("ShakeRoutine");
	}

	IEnumerator ShakeRoutine(){
		SetShake ();
		yield return new WaitForSeconds (0.6f);
		SetShake ();
	}

	public void ShakeForTime2(){
		StartCoroutine ("ShakeRoutine2");
	}

	IEnumerator ShakeRoutine2(){
		SetShake ();
		yield return new WaitForSeconds (0.2f);
		SetShake ();
	}
}
