﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyScrpt : MonoBehaviour {

	public bool destroyAfterTake;
    private AudioSource source;
    public AudioClip pickupClip;
    private bool taken = false;
	private bool dead = true;
	public ParticleSystem partSys;
	public GameObject key;
	private MeshRenderer keyRend;
	public GameObject[] walls;

	// Use this for initialization
	void Start () {
		partSys.Stop ();
        source = GetComponent<AudioSource>();
		keyRend = key.GetComponent<MeshRenderer> ();
		keyRend.enabled = false;

	}
	
	// Update is called once per frame
	void Update () {
        if (taken && !source.isPlaying)
        {
			
			StartCoroutine ("DieRoutine");
        }
    }

	public void OnTriggerEnter(Collider other){
		
			if (other.tag == "Player" && dead == true) {
				partSys.Play ();
				source.PlayOneShot(pickupClip);
				keyRend.enabled = true;
				foreach (GameObject wall in walls) {
					wall.GetComponent<WallUnlock> ().keyGet ();
				}
				if (destroyAfterTake) {
					taken = true;
					gameObject.GetComponent<Renderer>().enabled = false;
					DieRoutine ();
				}
				dead = false;
			}
	}

	IEnumerator DieRoutine(){
		yield return new WaitForSeconds (3f);
		Destroy(gameObject);
	}
}
