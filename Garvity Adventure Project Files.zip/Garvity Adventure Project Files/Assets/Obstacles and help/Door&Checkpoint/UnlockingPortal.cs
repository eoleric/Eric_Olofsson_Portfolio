﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnlockingPortal : MonoBehaviour {

    public int levelUnlocked;
    public GameObject portal;
    public GameObject portal2;
    public GameObject Ground1;
    public GameObject Ground2;
    public GameObject Ground3;

	void Start () {
        levelUnlocked = FindObjectOfType<GameManager>().sceneLevel;
        unlocked();
		
	}
	
	void Update () {
		
	}

    public void unlocked()
    {
        if(levelUnlocked >= 3)
        {
            Destroy(Ground1);
            Destroy(Ground2);
            Destroy(Ground3);

            portal.transform.Translate(0, -35, 0);
            portal2.transform.Translate(0, -35, 0);
        }
    }
}
