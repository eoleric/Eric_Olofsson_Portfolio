﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System;


public class DoorLeLeVel : MonoBehaviour


{

	public Text leVelElavator;
	public int level;
	public int sceneLevel;
    public int deaths;
    public ParticleSystem doorParticle;
	public GameObject doorUnlocked;

	public GameObject player;
	public bool unlocked = false;

	private AudioSource source;

	public AudioClip openClip;

	void Start () {
		doorParticle.Pause ();
		doorUnlocked.SetActive (false);
		try {
			sceneLevel = FindObjectOfType<GameManager> ().sceneLevel;
            isLocked();
		} catch (NullReferenceException) {
			if (level == 3) {
				unlocked = true;
			} else {
				unlocked = false;
			}
		}

		source = GetComponent<AudioSource> ();

	}
	
	void Update () {
		if (unlocked == true) {
			doorUnlocked.SetActive (true);
		} else {
			doorUnlocked.SetActive (false);
		}	
	}

	void OnTriggerEnter(Collider other){
		if (other.tag == "Player" && !doorParticle.isPlaying && unlocked){
			doorParticle.Play ();
		}
		if(other.tag == "Player"){
			leVelElavator.gameObject.SetActive (true);
		}
	}

	void OnTriggerExit(Collider other){
		if(other.tag == "Player"){
			leVelElavator.gameObject.SetActive (false);
			doorParticle.Stop ();
		}
	}

	void OnTriggerStay(Collider other){
		if (other.tag == "Player" && Input.GetButton("Enter")) {
			if (unlocked == true) {
                if (!source.isPlaying)
                {
                    source.PlayOneShot(openClip);
                }
                FindObjectOfType<GameManager>().currentLevel = level;
                deaths = player.GetComponent<Controller3D>().hearts;
                FindObjectOfType<GameManager>().setLife(deaths);
				FindObjectOfType<GameManager>().LoadLevel(level);


			}
		}
	}

	public void isLocked(){
		
		if(level == 3 && sceneLevel == 0){
			unlocked = true;
		} else if (level <= sceneLevel || sceneLevel + 1 == level) {
			unlocked = true;
		} else {
			unlocked = false;
		}
		
	}

}
