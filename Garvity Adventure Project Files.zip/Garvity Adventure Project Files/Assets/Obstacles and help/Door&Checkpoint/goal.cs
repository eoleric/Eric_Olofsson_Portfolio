﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class goal : MonoBehaviour {
	public int level;
    public int life;
    public int deaths;
    public GameObject player;
    private AudioSource source;
    public AudioClip winTune;
    bool taken = false;

	// Use this for initialization
	void Start () {
        source = GetComponent<AudioSource>();

    }
	
	// Update is called once per frame
	void Update () {
        if (taken && !source.isPlaying)
        {
            PlayerGoal();
        }
    }

	void OnTriggerEnter(Collider other){
		if (other.tag == "Player") {
            if (!source.isPlaying)
            {
                source.PlayOneShot(winTune);
            }
            taken = true;
            player.GetComponent<Controller3D>().BOXMODEACTIVATE(true);
		}
	}

    void PlayerGoal()
    {
        try
        {
            //FindObjectOfType<GameManager>().sceneLevel = level;
            life = player.GetComponent<Controller3D>().hearts;
            FindObjectOfType<GameManager>().setLife(life);
            
            if (level > FindObjectOfType<GameManager>().sceneLevel)
            {
                FindObjectOfType<GameManager>().sceneLevel = level;
            }
            //FindObjectOfType<GameManager> ().life = player.GetComponent<Controller3D>().SetHearts();
			FindObjectOfType<GameManager>().LoadLevel(2);
        }
        catch
        {
            Debug.Log("Ingen sceneLevel");
        }
    }
}
