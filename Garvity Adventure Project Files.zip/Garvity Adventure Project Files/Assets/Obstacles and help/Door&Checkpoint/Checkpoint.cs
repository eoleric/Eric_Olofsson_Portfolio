﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Checkpoint : MonoBehaviour {

	public GameObject player;
	public GameObject checkpoint;
	public ParticleSystem partSys;
	public bool topSide;
	public bool partSysPlayed = false;
	private Vector3 curPos;

	public Color damagedColor;
	//private Color standardColor;
	private Renderer rend;

    private AudioSource source;
    public AudioClip clip;

	void Start () {
		partSys.Stop ();
		rend = GetComponent<Renderer> ();
		//standardColor = rend.material.color;
        source = GetComponent<AudioSource>();
    }
	
	void Update () {
		
	}

	void OnTriggerEnter(Collider other){
		if (other.tag == "Player" && partSysPlayed == false) {
            source.PlayOneShot(clip);
			partSys.Play ();
			partSysPlayed = true;
			rend.material.color = damagedColor;
			saveLocation();
		}
	}

	public void saveLocation(){
		curPos = player.transform.position;
		player.GetComponent<Controller3D> ().startPos = curPos;
		player.GetComponent<Controller3D> ().startSide = topSide;
	}
}
