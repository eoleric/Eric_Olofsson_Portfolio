﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnlockingObjects : MonoBehaviour {

    private int levelUnlocked;
    public GameObject Parent2;
    public GameObject Parent3;
    public GameObject Parent4;

    // Use this for initialization
    void Start () {
        levelUnlocked = FindObjectOfType<GameManager>().sceneLevel;
        unlockingObjects();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void unlockingObjects()
    {
        Parent2.SetActive(false);
        Parent3.SetActive(false);
        Parent4.SetActive(false);

        if(levelUnlocked == 3)
        {
            Parent2.SetActive(true);

        } else if(levelUnlocked == 4)
        {
            Parent2.SetActive(true);
            Parent3.SetActive(true);

        } else if(levelUnlocked == 5)
        {
            Parent2.SetActive(true);
            Parent3.SetActive(true);
            Parent4.SetActive(true);
        }
    }
}
