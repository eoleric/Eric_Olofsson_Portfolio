﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformsVertical : MonoBehaviour {

	private GameObject PlatformMoving1;
	public float distance;
	public bool moving = false;
	public bool goUp = true;
	public Vector3 startPosition;
	public float velocityElevator;

	// Use this for initialization
	void Start () {
		PlatformMoving1 = gameObject;
		startPosition = PlatformMoving1.transform.position;
	}

	// Update is called once per frame
	void Update () {
		if (moving) {
			if (goUp) {
				PlatformMoving1.transform.Translate (Vector3.up * velocityElevator);
				if (PlatformMoving1.transform.position.y >= startPosition.y + distance) {
					goUp = false;
				}
			} else {
				PlatformMoving1.transform.Translate (Vector3.down * velocityElevator);
				if (PlatformMoving1.transform.position.y <= startPosition.y - distance) {
					goUp = true;
				}
			}
		}
	}

	void OnTriggerEnter(Collider other){
		if(other.gameObject.tag == "Player" ){
			Debug.Log ("child");
			other.transform.parent = gameObject.transform;
		}
	}


	void OnTriggerExit(Collider other){
		if(other.gameObject.tag == "Player" ){
			Debug.Log ("parent");
			other.transform.parent = null;
		}
	}
}
