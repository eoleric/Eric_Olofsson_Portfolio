﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformsHorizontal : MonoBehaviour {

	private GameObject PlatformMoving1;
	public float distance;
	public bool moving = false;
	public bool goLeft = true;
	public Vector3 startPosition;
	public float velocityElevator;

	// Use this for initialization
	void Start () {
		PlatformMoving1 = gameObject;
		startPosition = PlatformMoving1.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		if (moving) {
			if (goLeft) {
				PlatformMoving1.transform.Translate (Vector3.right * velocityElevator);
				if (PlatformMoving1.transform.position.x >= startPosition.x + distance) {
					goLeft = false;
				}
			} else {
				PlatformMoving1.transform.Translate (Vector3.left * velocityElevator);
				if (PlatformMoving1.transform.position.x <= startPosition.x - distance) {
					goLeft = true;
				}
			}
		}
	}

	void OnTriggerEnter(Collider other){
		if(other.gameObject.tag == "Player"){
			//Debug.Log ("child");
			other.transform.parent = gameObject.transform;
		}
	}


	void OnTriggerExit(Collider other){
		if(other.gameObject.tag == "Player"){
			//Debug.Log ("parent");
			other.transform.parent = null;
		}
	}
}
