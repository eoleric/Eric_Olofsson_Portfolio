﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;    
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
	

	public static GameManager instance = null;              
	private int level;   
	public int newlvl;


	//PlayerStats
	public GameObject player;
	private int life = 0;

	//Levels
	public int currentLevel;
	public int sceneLevel;

    private Renderer ren;
    public GameObject Blackscreeno;
	public Image blackimagerino;
    private Color bla = new Color(0, 0, 0, 1);
    private float feedsppedIn = 0.04f;
	private float feedsppedOut = 0.08f;
	private bool toneFromBlack = true;


    void Awake()
	{
		
		if (instance == null) {
			instance = this;
		} else if (instance != this) {
			Destroy (gameObject);    
		}

		DontDestroyOnLoad(gameObject);
		Blackscreeno = GameObject.FindGameObjectWithTag("Blackscreeno");
		blackimagerino = Blackscreeno.GetComponent<Image>();
        

        InitGame();
	}


	void InitGame()
	{
		

	}

    public int getLife()
    {
        return life;
    }

    public void setLife(int life)
    {
        this.life = life;
    }


	void Update()
	{
		if(Blackscreeno == null){
			Blackscreeno = GameObject.FindGameObjectWithTag("Blackscreeno");
			blackimagerino = Blackscreeno.GetComponent<Image>();
		}

		if (toneFromBlack) {
			if (blackimagerino.color.a > 0.05f) {
				bla.a = Mathf.Lerp (blackimagerino.color.a, 0, feedsppedIn);
				blackimagerino.color = bla;
			} else {
				Blackscreeno.SetActive (false);
			}	
		} else {
			//Blackscreeno.SetActive (true);
			if (blackimagerino.color.a < 0.98f) {
				bla.a = Mathf.Lerp (blackimagerino.color.a, 1, feedsppedOut);
				blackimagerino.color = bla;
			} else {
				bla = new Color(0, 0, 0, 1);
				toneFromBlack = true;
				SceneManager.LoadScene(newlvl);
			}	
		}
	}

	public void LoadLevel(int lvl){
		Blackscreeno.SetActive (true);
		newlvl = lvl;
		toneFromBlack = false;
	}
		
}