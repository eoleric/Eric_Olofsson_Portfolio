﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lvl2Button1 : MonoBehaviour {

	private GameObject button;
	//private Rigidbody rb;
	public GameObject[] objects;
	private bool box = true;
	private AudioSource source;
	public AudioClip buttonSound;
	private List<GameObject> children;
	public GameObject[] enemies;
	public GameObject[] addButtons;
	public GameObject[] removeButtons;
	public bool addPlatforms;
	public bool removePlatforms;

	public bool lvl3 = false;

	public float addStartTime = 0f;
	public float addDelayTime = 0f;


	// Use this for initialization
	void Start () {
		children = new List<GameObject> ();
		source = GetComponent<AudioSource> ();
		source.volume = 0.3f;
		button = gameObject;
		//rb = GetComponent<Rigidbody> ();
		foreach (GameObject parent in objects) {
			foreach (Transform child in parent.transform) {
				if (!child.gameObject.CompareTag("Enemy1") || !child.gameObject.CompareTag("Enemy2")) {
				children.Add (child.gameObject);
				}
			}
		}
		foreach (GameObject child in children) {
			if (removePlatforms) {
				child.SetActive (true);
			} else if (addPlatforms) {
				child.SetActive (false);
			}
		}

		foreach (GameObject enemy in enemies) {
			enemy.SetActive(false);
		}

		foreach (GameObject buttonz in addButtons) {
			Renderer[] buttonParts = buttonz.GetComponentsInChildren<Renderer> ();
			BoxCollider[] colliders = buttonz.GetComponentsInChildren<BoxCollider> ();
			foreach (Renderer render in buttonParts) {
					render.enabled = false;
			}
			foreach (BoxCollider collider in colliders) {
					collider.enabled = false;
			}
		}

	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter (Collider other){
		if (box == true && other.tag == "Player") {
			StartCoroutine (spawnObjects());
            source.PlayOneShot(buttonSound);
            button.transform.Translate (new Vector3 (0, -0.075f, 0));
			box = false;
		} 
	}

	private IEnumerator spawnObjects() {
		GameObject tempPlayer = GameObject.FindGameObjectWithTag ("Player");
		GameObject tempCamera = GameObject.FindGameObjectWithTag ("MainCamera");
		if(lvl3)
			tempCamera.GetComponent<Camera2D> ().ZoomInOrOut2 ();
		else
			tempCamera.GetComponent<Camera2D> ().ZoomInOrOut ();
		tempPlayer.GetComponent<Controller3D> ().BOXMODEACTIVATE (true);

		yield return new WaitForSeconds (addStartTime);

		foreach (GameObject button in removeButtons) {
			Renderer[] buttonParts = button.GetComponentsInChildren<Renderer> ();
			BoxCollider[] colliders = button.GetComponentsInChildren<BoxCollider> ();
			foreach (Renderer render in buttonParts) {
				render.enabled = false;
			}
			foreach (BoxCollider collider in colliders) {
				collider.enabled = false;
			}
		}

		foreach (GameObject child in children) {
			if (child.gameObject.active == true) {
					child.gameObject.SetActive (false);
					yield return new WaitForSeconds (0.04f);
			} else if(child.gameObject.active == false) {
					child.gameObject.SetActive (true);
					yield return new WaitForSeconds (0.04f);
				}
		}

		foreach (GameObject enemy in enemies) {
			if (enemy.gameObject.active == false) {
				enemy.SetActive (true);
			} else {
				enemy.SetActive (false);
			}
		}

		foreach (GameObject button in addButtons) {
			Renderer[] buttonParts = button.GetComponentsInChildren<Renderer> ();
			BoxCollider[] colliders = button.GetComponentsInChildren<BoxCollider> ();
			foreach (Renderer render in buttonParts) {
					render.enabled = true;
			}
			foreach (BoxCollider collider in colliders) {
					collider.enabled = true;
			}
		}

		yield return new WaitForSeconds (addDelayTime);

		tempPlayer.GetComponent<Controller3D> ().BOXMODEACTIVATE (false);
		if(lvl3)
			tempCamera.GetComponent<Camera2D> ().ZoomInOrOut2 ();
		else
			tempCamera.GetComponent<Camera2D> ().ZoomInOrOut ();
	}
}
