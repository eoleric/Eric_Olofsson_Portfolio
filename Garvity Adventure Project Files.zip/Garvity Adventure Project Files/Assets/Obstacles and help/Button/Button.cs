﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour {

	public GameObject PlatformMoving1;
	public float distance;
	public bool moving = false;
	public bool goUp = true;
	public bool up = true;
	public Vector3 startPosition;
	public float velocityElevator = 0.05f;
	public float timerHallway = 0f;
	//public GameObject Butt;
	private bool counter;
	public int sceneLevel;
	public bool notHUB;
	public bool bossLvl;
	public bool onlyUseOnce = false;
	private bool used = false;

	public bool moveOnce = false;

	// Use this for initialization
	void Start () {
		startPosition = PlatformMoving1.transform.position;
		sceneLevel = FindObjectOfType<GameManager> ().sceneLevel;
		counter = true;
	}
	
	// Update is called once per frame
	void Update () {
		if (moving) {
			if(up){
				if (goUp) {
					PlatformMoving1.transform.Translate (Vector3.up * velocityElevator);
					if (PlatformMoving1.transform.position.y >= startPosition.y + distance) {
						goUp = false;
						if (moveOnce) {
							moving = false;
						}
					}
				} else {
					PlatformMoving1.transform.Translate (Vector3.down * velocityElevator);
					if (PlatformMoving1.transform.position.y <= startPosition.y - distance) {
						goUp = true;
					}
				}
			} else {
				if (goUp) {
					PlatformMoving1.transform.Translate (Vector3.right * velocityElevator);
					if (PlatformMoving1.transform.position.x >= startPosition.x + distance) {
						goUp = false;
					}
				} else {
					PlatformMoving1.transform.Translate (Vector3.left * velocityElevator);
					if (PlatformMoving1.transform.position.x <= startPosition.x - distance) {
						goUp = true;
					}
				}
			}
		}
	}

	void OnTriggerEnter(Collider other){
		if((other.gameObject.CompareTag("Player") && Time.time - timerHallway > 1f && ((sceneLevel >= 2) || notHUB)) && !used){
			

			if (onlyUseOnce) {
				used = true;
			}
			moving = !moving;
			timerHallway = Time.time;
			if (counter == true) {
				gameObject.transform.Translate (Vector3.down * 0.05f);
				//Debug.Log ("down");
				counter = false;
			}else {
				gameObject.transform.Translate (Vector3.up * 0.05f);
				//Debug.Log ("up");
				counter = true;
			}

//			counter = !counter;

		}
	}

}
