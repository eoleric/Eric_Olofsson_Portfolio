﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxSounds : MonoBehaviour {

	private AudioSource source;
	public AudioClip boxSounds;
	private float boxVelocity;
	private float prevPos;
	private float currVel;

	// Use this for initialization
	void Start () {
		source = GetComponent<AudioSource> ();
		source.clip = boxSounds;
		source.loop = true;
        source.volume = 0.4f;
		source.Play ();

		StartCoroutine( CalcVelocity() );
	}

	IEnumerator CalcVelocity()
	{
		while( Application.isPlaying )
		{
			prevPos = transform.position.x;
			yield return new WaitForEndOfFrame();
			currVel = (prevPos - transform.position.x) / Time.deltaTime;
		}
	}

	void Update () {

		if (currVel < 0.01 && currVel > -0.01) {
			source.Pause ();
		} else {
			if(!source.isPlaying){
				source.Play ();
			}
		}
	}
}
