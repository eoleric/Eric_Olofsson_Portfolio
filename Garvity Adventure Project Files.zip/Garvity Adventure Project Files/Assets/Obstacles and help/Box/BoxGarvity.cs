﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxGarvity : MonoBehaviour {

	private Velocity3D velocity;
	//private Vector3 startPos;

	public float Gravity { get; private set; }
	public float MaxJumpHeight = 4.0f;
	public float MinJumpHeight = 1.0f;
	public float TimeToJumpApex = 0.4f;
	public bool topSide = true;
	//private bool startSide;
	public float TerminalVelocity = 18.0f;
	//private CharacterController characterController;

	// Use this for initialization
	void Start () {
		
	}

	private void Awake()
	{
		//startPos = transform.position;
		//startSide = topSide;
		CreateVelocity();
		CacheComponents();
		CalculateGravity();
	}
	
	// Update is called once per frame
	void Update () {

		CalculateGravity();
		velocity.AddY (Gravity * Time.deltaTime);
		
	}

	private void CreateVelocity()
	{
		velocity = new Velocity3D(-TerminalVelocity, gameObject);
	}

	private void CacheComponents()
	{
		//characterController = GetComponent<CharacterController>();
	}

	public void CalculateGravity()
	{
		if (topSide)
		{
			Gravity = -(2 * MaxJumpHeight) / Mathf.Pow(TimeToJumpApex, 2);
		}
		else
		{
			Gravity = (2 * MaxJumpHeight) / Mathf.Pow(TimeToJumpApex, 2);
		}
	}

	public void SetTopSide(){
		Debug.Log ("switch");
		topSide = !topSide;
		CalculateGravity ();
	}

	public void SetTopSide(bool side){
		Debug.Log ("switch");
		topSide = side;
		CalculateGravity ();
	}

//	private bool CheckCollision(Vector3 input){
//
//	}
}
