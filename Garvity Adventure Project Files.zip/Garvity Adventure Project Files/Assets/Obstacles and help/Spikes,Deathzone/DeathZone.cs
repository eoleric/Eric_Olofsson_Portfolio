﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathZone : MonoBehaviour {

    private AudioSource source;
    public AudioClip playerDeathSound;

	// Use this for initialization
	void Start () {
        source = GetComponent<AudioSource>();
        source.volume = 0.3f;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerStay(Collider other) {
		if (other.tag == "Player") {
            source.PlayOneShot(playerDeathSound);
            other.gameObject.GetComponent<Controller3D> ().Die ();
		} 

		if(other.tag == "Box"){
			other.gameObject.GetComponent<Controller3D> ().Die ();
		}else {
			//Destroy (other.gameObject);
		}
	}
}
