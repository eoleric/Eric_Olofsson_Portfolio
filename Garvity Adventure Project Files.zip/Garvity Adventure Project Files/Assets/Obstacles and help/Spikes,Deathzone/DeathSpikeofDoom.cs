﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathSpikeofDoom : MonoBehaviour {

	private float spikeDamage = 100f;
    private AudioSource source;
    public AudioClip DmgClip;
    public AudioClip BoxBreakClip; 
	public float instaDmg;


    // Use this for initialization
    void Start () {
        source = GetComponent<AudioSource>();

	}

	// Update is called once per frame
	void Update () {
	}

	void OnTriggerStay(Collider other){
		if (other.tag == "Player") {
			source.PlayOneShot (DmgClip);
			other.GetComponent<Controller3D> ().Damage (instaDmg);
			other.GetComponent<Controller3D> ().Damage (spikeDamage * Time.deltaTime);
		} else if (other.tag == "Box") {
			source.PlayOneShot (BoxBreakClip);
			other.GetComponent<Controller3D> ().Die ();		
		} else if (other.tag == "Enemy1" && Vector3.Distance (other.gameObject.transform.position, transform.position) < 0.5f) {
			other.GetComponent<enemy1> ().Die ();
		} else if (other.tag == "Boss") {
			other.GetComponent<Boss> ().Damage (10f);
		}
	}
}
