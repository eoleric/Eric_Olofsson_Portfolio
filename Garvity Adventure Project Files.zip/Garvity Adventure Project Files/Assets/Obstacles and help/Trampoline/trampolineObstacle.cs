﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class trampolineObstacle : MonoBehaviour {

	public int sceneLevel;

	// Use this for initialization
	void Start () {
		sceneLevel = FindObjectOfType<GameManager> ().sceneLevel;
		if(sceneLevel >= 3){
			Destroy (gameObject);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}


}
