﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class trampoline : MonoBehaviour {

	public float trampolineSpeed;
	public ParticleSystem bounce;
	private Vector3 position;

    private AudioSource source;
    public AudioClip clip;

	// Use this for initialization
	void Start () {
		bounce.Stop ();
        source = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
	}

	void OnTriggerEnter(Collider other){
		if (other.gameObject.tag == "Player") {
			Controller3D controller = other.gameObject.GetComponent<Controller3D> ();
			position = other.transform.position;
			bounce.transform.position = position;
			bounce.Play();
            source.PlayOneShot(clip);
            source.pitch = Random.Range(0.9f, 1.2f);
            source.volume = Random.Range(0.3f, 0.6f);
			controller.GetVelocity ().ResetHorizontalVelocity ();
			if (controller.topSide) {
				controller.transform.Translate (Vector3.up * 0.4f);
				controller.GetVelocity().SetY (trampolineSpeed);
			} else {
				controller.transform.Translate (Vector3.down * 0.4f);
				controller.GetVelocity().SetY (-trampolineSpeed);
			}
		}
	}
}
