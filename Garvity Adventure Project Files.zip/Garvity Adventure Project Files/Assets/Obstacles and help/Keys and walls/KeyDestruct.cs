﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyDestruct : MonoBehaviour {

	private int timesUsed;
	public int maxTimesUsed;

	// Use this for initialization
	void Start () {
		timesUsed = 0;
	}

	public void doorUnlock(){
		timesUsed++;
	}
	
	// Update is called once per frame
	void Update () {
	}

	public void destroyKey(){
		if (timesUsed == maxTimesUsed) {
			gameObject.SetActive (false);
		} else {
			return;
		}
	}
}
