﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallUnlock : MonoBehaviour {

	private bool keyPickedUp = false;
	public KeyDestruct key;

	// Use this for initialization
	void Start () {
		
	}

	public void keyGet(){
		keyPickedUp = true;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider other){
		if (other.tag=="Player" && keyPickedUp){
			key.doorUnlock ();
			key.destroyKey();
			other.GetComponent<Controller3D> ().playDoorSound();
			Destroy (gameObject);
		}
	}
}
