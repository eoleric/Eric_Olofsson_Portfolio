﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum HorizontalDirectionZ {
	still = 0,
	toward = 1,
	away = -1
}
