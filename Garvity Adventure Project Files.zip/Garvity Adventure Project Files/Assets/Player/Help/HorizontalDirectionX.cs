﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum HorizontalDirectionX {
	still = 0,
	right = 1,
	left = -1
}
