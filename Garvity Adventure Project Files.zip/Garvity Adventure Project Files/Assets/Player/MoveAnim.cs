﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveAnim : MonoBehaviour {

	public GameObject[] bottomRend;
	public GameObject[] topRend;

	private Vector3 shakePos;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {


		
	}
}
