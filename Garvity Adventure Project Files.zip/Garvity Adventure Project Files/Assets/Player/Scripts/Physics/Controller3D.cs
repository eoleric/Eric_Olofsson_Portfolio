﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
[RequireComponent(typeof(CharacterController))]
public class Controller3D : MonoBehaviour
{
	#region Constants
	public readonly KeyCode JumpKey = KeyCode.Space;
	#endregion
	[Tooltip("Units per second")]
	public float MoveSpeed = 6.0f;

	private float startZ;

	public Vector3 startPos;
	public Text deathCounter;

	public Slider healthbar;

	[Tooltip("Degrees per second")]
	public float RotationSpeed = 120.0f;
	[Tooltip("Units per second when jumping while sliding down a slope")]
	public float SlideJumpSpeed = 10.0f;
	[Tooltip("Maximum downwards velocity (entered as a positive value)")]
	public float TerminalVelocity = 18.0f;
	public float GroundAccelerationTime = 0.1f;
	public float AirAccelerationTime = 0.2f;
	public float GroundDeaccelerationScale = 0.8f;
	public float AirDeaccelerationScale = 3.5f;
	[Tooltip("The maximum jump height in units")]
	public float MaxJumpHeight = 4.0f;
	[Tooltip("The smallest jump height possible in units")]
	public float MinJumpHeight = 1.0f;
	[Tooltip("The time it takes (seconds) to reach the maximum jump height")]
	public float TimeToJumpApex = 0.4f;
	private CharacterController characterController;

	public float healthCounter = 100f;
	public int hearts = 0; 

	public Camera2D camera;
	//public Camera3D camera3D;
    public bool topSide = true;
	public bool startSide;
	public bool Set2D;
	public bool isBox;
	[HideInInspector]
    public bool isPaused = false;

    private int level;
	private float prevPos;
	private float currVel;
	private float animationVelocity;

	private Velocity3D velocity;
	public ICharacterState3D characterState;
	public float MaxJumpVelocity { get; private set; }
	public float MinJumpVelocity { get; private set; }
	public float Gravity { get; private set; }
	public float MaxTraversableSlopeAngle
	{
		get { return characterController.slopeLimit; }
	}
	public float ColliderHeight
	{
		get { return characterController.height; }
	}

	private AudioSource [] sources;
	private AudioSource source1;
	private AudioSource source2;
	public AudioClip jump;
	public AudioClip walk;
	public AudioClip portalSound;
	public AudioClip checkpointSound;
	public AudioClip doorSound;

	public Image dmgVignette;
    public GameObject pausMenu;
    public GameObject deathCanvas;
	public GameObject ButtonParent;
	public Selectable startButton;

	public Animator anim;
	//private bool isInAir = false;

	private bool locky = false;
	private float posy;



	public void ChangeCharacterState(CharacterStateSwitch3D stateSwitch)
	{
		PrintStateSwitch(stateSwitch);
		characterState.Exit();
		characterState = stateSwitch.NewState;
		characterState.Enter();
		if (stateSwitch.RunImmediately)
		{
			characterState.Update(stateSwitch.MovementInput, stateSwitch.DeltaTime);
		}
	}
	public bool IsTraversableSlope(float maxDistance)
	{
		var groundSlopeAngle = 0.0f;
		RaycastHit hitInfo;
		if (Physics.Raycast(transform.position, Vector3.down, out hitInfo,
			maxDistance))
		{
			groundSlopeAngle = Vector3.Angle(Vector3.up, hitInfo.normal);
		}
		return groundSlopeAngle <= MaxTraversableSlopeAngle;
	}

	void Start(){
		

		//anim.enabled = true;
		sources = GetComponents<AudioSource> ();
		source1 = sources [0];
		source1.clip = walk;
		source1.loop = true;
		source2 = sources [1];
		StartCoroutine(CalcYVelocity());
    }

//	public void SetAnimationSpeed (){
//		animationVelocity = velocity.getVelocity().x;
//	}

	private void Awake()
	{
		anim = GetComponent<Animator> ();
		startPos = transform.position;
		startZ = transform.position.z;
		startSide = topSide;
		CreateVelocity();
		CacheComponents();
		CalculateGravity();
		CalculateJumpVelocities();
		SetInitialCharacterState();
		if (!isBox) {
            hearts = FindObjectOfType<GameManager>().getLife();
            SetHearts ();
		}
		Cursor.visible = false;
	}


	IEnumerator CalcYVelocity()
	{
		while( Application.isPlaying )
		{
			prevPos = transform.position.y;
			yield return new WaitForEndOfFrame();
			currVel = (prevPos - transform.position.y) / Time.deltaTime;
		}
	}

	public void setInAir(bool inAir){
		anim.SetBool ("InAir", inAir);
	}

	public void setFell(bool inAir){
		anim.SetBool ("Fell", inAir);
	}

	public void setJumped(bool inAir){
		anim.SetBool ("Jumped", inAir);
	}

	private void Update()
	{
        string[] controllerNames = Input.GetJoystickNames();
        for(int i = 0; i < controllerNames.Length; i++)
        {
            if(!string.IsNullOrEmpty(controllerNames[i]))
            {
                MoveSpeed = 6.5f;
            }
            if(string.IsNullOrEmpty(controllerNames[i]))
            {
                MoveSpeed = 6.0f;
            }
        }
		transform.position = new Vector3 (transform.position.x, transform.position.y, startZ);
        returnToHub();
		dmgVignette.color = Color.Lerp (dmgVignette.color, new Color(0f,0f,0f,0f), Time.deltaTime * 5f);
		//SetAnimationSpeed ();

		if (velocity.getVelocity ().x < 0.3f && velocity.getVelocity ().x > -0.3f && velocity.getVelocity ().z < 0.3f && velocity.getVelocity ().z > -0.3f  || currVel > 0.1f || currVel < -0.1f) {
			source1.Pause ();
			anim.SetFloat ("MovingSpeed", 0f);
		} else {
			if (!source1.isPlaying && !isPaused) {
				source1.Play ();
				anim.SetFloat ("MovingSpeed", 1f);
			}
		}

		if (currVel < 0.1f && currVel > -0.1f && Input.GetButtonDown ("Jump") && !isBox) {
			source2.PlayOneShot (jump);
		} 
		var deltaTime = Time.deltaTime;
		RotateCharacter(deltaTime);
		characterState.Update(GetMovementInput(), deltaTime);
		HandleCollisions(Move());
		DrawAxes();
		checkGroundShake ();
		if (locky && isBox) {
			gameObject.transform.position = new Vector3 (gameObject.transform.position.x, posy, gameObject.transform.position.z);
		}
		posy = gameObject.transform.position.y;

		if (((Input.GetAxis("Horizontal") > 0) && topSide) || ((Input.GetAxis("Horizontal") < 0) && !topSide))
        {
            anim.SetFloat("Speed", -1);
        }
		if (((Input.GetAxis("Horizontal") < 0) && topSide) || ((Input.GetAxis("Horizontal") > 0) && !topSide))
        {
            anim.SetFloat("Speed", 1);
        }
    }

	private void CacheComponents()
	{
		characterController = GetComponent<CharacterController>();
	}
	public void CalculateGravity()
	{
        if (topSide)
        {
            Gravity = -(2 * MaxJumpHeight) / Mathf.Pow(TimeToJumpApex, 2);
        }
        else
        {
            Gravity = (2 * MaxJumpHeight) / Mathf.Pow(TimeToJumpApex, 2);
        }
	}
	private void CalculateJumpVelocities()
	{
		var positiveGravity = Mathf.Abs(Gravity);
		MaxJumpVelocity = positiveGravity * TimeToJumpApex;
		MinJumpVelocity = Mathf.Sqrt(2 * positiveGravity * MinJumpHeight);
	}
	private void CreateVelocity()
	{
		velocity = new Velocity3D(-TerminalVelocity, gameObject);
	}
	private void SetInitialCharacterState()
	{
		if (characterController.isGrounded)
		{
			// Using an arbitrarily distance. If this distance doesn't return true the angle is STEEP.
			if (IsTraversableSlope(ColliderHeight * 10.0f))
			{
				characterState = new SlideState3D(this, velocity, topSide, gameObject);
			}
			else
			{
				characterState = new GroundState3D(this, velocity, topSide, gameObject);
            }
		}
		else
		{
			characterState = new AirState3D(this, velocity, topSide, gameObject, false);
		}
	}
	private void RotateCharacter(float deltaTime)
	{
		if (Input.GetKey(KeyCode.Keypad6) && !Set2D)
		{
			transform.RotateAround(transform.position, transform.up, deltaTime *
				RotationSpeed);
		}
		else if (Input.GetKey(KeyCode.Keypad4) && !Set2D)
		{
			transform.RotateAround(transform.position, transform.up, -deltaTime *
				RotationSpeed);
		}
	}
	private Vector3 GetMovementInput()
	{
		if (isBox) {
			return new Vector3 (0.0f, 0.0f, 0.0f);
		} else if (Set2D) {
			return new Vector3 (Input.GetAxisRaw ("Horizontal"), 0.0f, 0.0f);

		}else {
			return new Vector3 (Input.GetAxisRaw ("Horizontal"), 0.0f, Input.GetAxisRaw("Vertical"));

		}
		}
	private CollisionFlags Move()
	{
		// The Move() method of a CharacterController takes a vector in world space. Since the velocity is
		// using local space we need to convert it to world space first.
		var moveDirection = transform.TransformDirection(velocity.Current).normalized;
		var moveLength = velocity.Current.magnitude;
		var motion = moveDirection * moveLength;
		return characterController.Move(motion);
	}
	private void HandleCollisions(CollisionFlags collisionFlags)
	{
		var stateSwitch = characterState.HandleCollisions(collisionFlags);
		if (stateSwitch.NewState != null)
		{
			ChangeCharacterState(stateSwitch);
		}
	}
	[System.Diagnostics.Conditional("UNITY_EDITOR")]
	private void DrawAxes()
	{
		Debug.DrawRay(transform.position + transform.forward * characterController.radius, transform.forward, Color.blue);
		Debug.DrawRay(transform.position + transform.right * characterController.radius, transform.right, Color.red);
		Debug.DrawRay(transform.position + transform.up * characterController.height * 0.5f, transform.up, Color.green);
	}
	[System.Diagnostics.Conditional("UNITY_EDITOR")]
	private void PrintStateSwitch(CharacterStateSwitch3D stateSwitch)
	{
		//print("Switching character state from " + characterState.ToString() + " to " + stateSwitch.NewState.ToString());
	}

    public Animator getAnim()
    {
        return anim;
    }

	public void SetTopSide(){
		topSide = !topSide;
		characterState.SetTopSide (topSide);
		CalculateGravity ();
		source2.PlayOneShot (portalSound);
	//	camera.flipCamera (topSide);
		//gameObject.GetComponent<CharacterController> ().stepOffset = gameObject.GetComponent<CharacterController> ().stepOffset * -1f;
	}

	public void SetTopSide(bool side){
		topSide = side;
		characterState.SetTopSide (topSide);
		CalculateGravity ();
//		if(!isBox)
//			camera.flipCamera (side);
		//gameObject.GetComponent<CharacterController> ().stepOffset = gameObject.GetComponent<CharacterController> ().stepOffset * -1f;
	}

    public void returnToHub()
     {
		if (Input.GetButtonDown("Exit"))
        {
            if (!isBox)
            {
                if (!isPaused)
                {
                    Time.timeScale = 0;
                    deathCanvas.SetActive(false);
                    pausMenu.SetActive(true);
					ButtonParent.GetComponent<SelectOnInput> ().SetSelcted(startButton.gameObject);
					startButton.Select ();
                    isPaused = true;
                }
                else
                { 
                    Time.timeScale = 1;
                    pausMenu.SetActive(false);
                    deathCanvas.SetActive(true);
                    isPaused = false;
                }

            }
        }
    }

	public Velocity3D GetVelocity(){
		return velocity;
	}

	public void Die(){
		
		if (!isBox) {
			GameObject boss = GameObject.FindGameObjectWithTag("Boss");
			if (boss != null) {
				if (boss.GetComponent<Boss> ().characterState as BossTrackState != null) {
					(boss.GetComponent<Boss> ().characterState as BossTrackState).resetTrack ();
				}
			}

			GameObject[] enemy2s = GameObject.FindGameObjectsWithTag("Enemy2");
			foreach(GameObject g in enemy2s){
				g.GetComponent<enemy2> ().reset ();
			}
			healthCounter = 100f;
			hearts += 1;
//			if (hearts < 1) {
//				hearts = 3;
//                level = FindObjectOfType<GameManager>().currentLevel;
//                SceneManager.LoadScene(level);
//                
//			}
			healthbar.value = healthCounter;
			SetHearts ();
        }

        velocity.ResetHorizontalVelocity();
        velocity.SetY(0f);
        transform.position = startPos;
        SetTopSide (startSide);
		healthCounter = 100f;
    }

	public void Damage(float damage){


		healthCounter -= damage;
		healthbar.value = healthCounter;

		Color fullColor = new Color (1, 1, 1, 1);
		dmgVignette.color = fullColor;

		if (healthCounter < 1) {
			Die ();
		}

	}


	void checkGroundShake() {
		RaycastHit hitInfo;
		if (topSide) {
			if (Physics.Raycast (transform.position, Vector3.down, out hitInfo, 0.5f)) {
				if (hitInfo.collider.gameObject.CompareTag ("Shaking")) {

					SetTopSide ();
				}
			}
		}
		if (!topSide) {
			if (Physics.Raycast (transform.position, Vector3.up, out hitInfo, 0.5f)) {
				if (hitInfo.collider.gameObject.CompareTag ("Shaking")) {

					SetTopSide ();
				}
			}
		}
	}

	public void SetHearts(){
		deathCounter.text = "Deaths: " + hearts;
		FindObjectOfType<GameManager> ().setLife (hearts);
//		heart1.SetActive (true);
//		heart2.SetActive (true);
//		heart3.SetActive (true);
//
//		if (hearts == 1) {
//			heart2.SetActive (false);
//			heart3.SetActive (false);
//		} else if (hearts == 2) {
//			heart3.SetActive (false);
//		} 
	}

	public void playDoorSound(){
		source2.PlayOneShot (doorSound);
	}

	public void BOXMODEACTIVATE(bool work){
		if (work) {
			isBox = true;
		} else {
			isBox = false;
		}
	}

	void OnTriggerEnter(Collider other){
		if (other.tag == "Player") {
			locky = true;
		}
	}

	void OnTriggerExit(Collider other){
		if (other.tag == "Player") {
			locky = false;
		}
	}
}