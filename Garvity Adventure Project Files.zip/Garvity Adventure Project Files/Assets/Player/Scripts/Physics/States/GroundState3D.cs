﻿using System;
using UnityEngine;
public struct GroundState3D : ICharacterState3D
{
	private readonly Controller3D controller;
	private readonly Velocity3D velocity;
    private bool topSide;
    private CollisionFlags currentColFlag;
	private GameObject owner;

	public GroundState3D(Controller3D controller, Velocity3D velocity, bool topSide, GameObject owner)
	{
		if (controller == null)
		{
			throw new ArgumentNullException("controller");
		}
		if (velocity == null)
		{
			throw new ArgumentNullException("velocity");
		}
		this.controller = controller;
		this.velocity = velocity;
        this.topSide = topSide;
        if (topSide)
        {
            currentColFlag = CollisionFlags.Below;
        }
        else
        {
            currentColFlag = CollisionFlags.Above;
        }
		this.owner = owner;
    }
	public void Enter()
	{
		// Since other states may have worked magic with the gravity we reset it so we start from scratch.
		velocity.SetY(0.0f);

	}
	public void Exit()
	{
		// NOTE: Empty by choice. Here for demonstration purposes.
	}
	public void Update(Vector3 movementInput, float deltaTime)
	{
		if (Input.GetButtonDown("Jump") && !owner.GetComponent<Controller3D>().isBox)
		{
			var stateSwitch = new CharacterStateSwitch3D(new AirState3D(controller, velocity, topSide, owner, true), movementInput, deltaTime, true);
			controller.ChangeCharacterState(stateSwitch);
		}
		else
		{
			UpdateVelocity(movementInput, deltaTime);
		}
	}

    public CharacterStateSwitch3D HandleCollisions(CollisionFlags collisionFlags)
    {
		RaycastHit hit;
		if (owner.GetComponent<Controller3D> ().isBox) {
			if(Physics.Raycast(new Vector3(owner.transform.position.x -0.41f , owner.transform.position.y - 0.2f, owner.transform.position.z) , Vector3.left, out hit, 0.1f) || Physics.Raycast(new Vector3(owner.transform.position.x -0.41f , owner.transform.position.y + 0.2f, owner.transform.position.z) , Vector3.left, out hit, 0.1f)){
				if (hit.transform.tag == "Player") {
					owner.transform.Translate (Vector3.right * Time.deltaTime * 2);
				}
			}
			if(Physics.Raycast(new Vector3(owner.transform.position.x + 0.41f , owner.transform.position.y - 0.2f, owner.transform.position.z) , Vector3.right, out hit, 0.1f) || Physics.Raycast(new Vector3(owner.transform.position.x + 0.41f , owner.transform.position.y + 0.2f, owner.transform.position.z) , Vector3.right , out hit, 0.1f)){
				if (hit.transform.tag == "Player") {
					owner.transform.Translate (Vector3.left * Time.deltaTime * 2);
				}
			}
		}

        CharacterStateSwitch3D stateSwitch;
        if ((collisionFlags & currentColFlag) == currentColFlag)
        {
//			if (owner.GetComponent<Controller3D> ().isBox) {
//				if()
//			}
            stateSwitch = new CharacterStateSwitch3D();
        }
		else
		{
			stateSwitch = new CharacterStateSwitch3D(new AirState3D(controller, velocity, topSide, owner, false));
			controller.ChangeCharacterState(stateSwitch);
		}
		return stateSwitch;
	}
	private void UpdateVelocity(Vector3 movementInput, float deltaTime)
	{
		var smoothDampDataX = GetSmoothDampData(movementInput.x);
		var smoothDampDataZ = GetSmoothDampData(movementInput.z);
        // Using an arbitrary gravity here that, hopefully, is enough to allow use tomaintain grounded
        // regardless of the slope and speed. This may need to be adjusted depending onthe game.
        // Actually, it may work well with a very big negative number if we alwayschange the y velocity
        // to 0 whenever we switch state. Something to try.
        if (topSide)
        {
            velocity.SetY(-20.0f);
        }
        else
        {
            velocity.SetY(20.0f);
        }
		velocity.SmoothDampUpdate(movementInput, smoothDampDataX, smoothDampDataZ, deltaTime);
	}

	private SmoothDampData GetSmoothDampData(float input)
	{
		var targetVelocity = input * controller.MoveSpeed;
		var smoothTime = controller.GroundAccelerationTime;
		if (Mathf.Abs(input) < MathHelper.FloatEpsilon)
		{
			smoothTime *= controller.GroundDeaccelerationScale;
		}
		return new SmoothDampData(targetVelocity, smoothTime);
	}

	public void SetTopSide(bool top){
		topSide = top;
	}
}