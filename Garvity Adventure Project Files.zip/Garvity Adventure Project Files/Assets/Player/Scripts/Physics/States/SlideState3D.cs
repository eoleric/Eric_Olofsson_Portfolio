﻿using System;
using UnityEngine;
public struct SlideState3D : ICharacterState3D
{
	private readonly Controller3D controller;
	private readonly Velocity3D velocity;
    private bool topSide;
	private GameObject owner;
	public SlideState3D(Controller3D controller, Velocity3D velocity, bool topSide,GameObject owner)
	{
		if (controller == null)
		{
			throw new ArgumentNullException("controller");
		}
		if (velocity == null)
		{
			throw new ArgumentNullException("velocity");
		}
		this.controller = controller;
		this.velocity = velocity;
        this.topSide = topSide;
		this.owner = owner;
	}
	public void Enter()
	{
		// Since other states may have worked magic with the gravity we reset it so we start from scratch.
		velocity.SetY(0.0f);
	}
	public void Exit()
	{
		// NOTE: Empty by choice. Here for demonstration purposes.
	}
	public void Update(Vector3 movementInput, float deltaTime)
	{
		if (Input.GetKeyDown(KeyCode.Space))
		{
			RaycastHit hitInfo;
			if (Physics.Raycast(controller.transform.position, Vector3.down, out
				hitInfo, controller.ColliderHeight))
			{
				movementInput = hitInfo.normal * controller.SlideJumpSpeed;
			}
			var stateSwitch = new CharacterStateSwitch3D(new AirState3D(controller, velocity, topSide, owner, true), movementInput, deltaTime, true);
			controller.ChangeCharacterState(stateSwitch);
		}
		else
		{
			UpdateVelocity(movementInput, deltaTime);
		}
	}
	public CharacterStateSwitch3D HandleCollisions(CollisionFlags collisionFlags)
	{
		CharacterStateSwitch3D stateSwitch;
		if ((collisionFlags & CollisionFlags.Below) == CollisionFlags.Below)
		{
			stateSwitch = new CharacterStateSwitch3D();

			RaycastHit hitInfo;
			if (Physics.Raycast(controller.transform.position, Vector3.down, out hitInfo, controller.ColliderHeight))
			{
				if (Vector3.Angle(hitInfo.normal, Vector3.up) <= controller.MaxTraversableSlopeAngle)
				{
					stateSwitch = new CharacterStateSwitch3D(new GroundState3D(controller, velocity, topSide, owner));
				}
			}
			else
			{
				stateSwitch = new CharacterStateSwitch3D(new AirState3D(controller, velocity, topSide, owner, false));
				controller.ChangeCharacterState(stateSwitch);
			}
		}
		else
		{
			stateSwitch = new CharacterStateSwitch3D(new AirState3D(controller, velocity, topSide, owner, false));
			controller.ChangeCharacterState(stateSwitch);
		}
		return stateSwitch;
	}
	private void UpdateVelocity(Vector3 movementInput, float deltaTime)
	{
		RaycastHit hitInfo;
		if (Physics.Raycast(controller.transform.position, Vector3.down, out hitInfo,
			controller.ColliderHeight))
		{
			// Set the movement input based on the normal of the surface. Since the normal is given in world
			// coordinates and the movement input is using local coordinates we need to transform the vector
			// from world to local using the InverseTransformDirection() method.
			var normalVectorWithInvertedY = new Vector3(hitInfo.normal.x, -	hitInfo.normal.y, hitInfo.normal.z);
			movementInput = controller.transform.InverseTransformDirection(normalVectorWithInvertedY).normalized;
		}
		var smoothDampDataX = GetSmoothDampData(movementInput.x);
		var smoothDampDataZ = GetSmoothDampData(movementInput.z);
		velocity.AddY(controller.Gravity * deltaTime);
		velocity.SmoothDampUpdate(movementInput, smoothDampDataX, smoothDampDataZ, deltaTime);
	}
	private SmoothDampData GetSmoothDampData(float input)
	{
		var targetVelocity = input * controller.MoveSpeed;
		var smoothTime = controller.GroundAccelerationTime;
		if (Mathf.Abs(input) < MathHelper.FloatEpsilon)
		{
			smoothTime *= controller.GroundDeaccelerationScale;
		}
		return new SmoothDampData(targetVelocity, smoothTime);
	}

	public void SetTopSide(bool top){
		topSide = top;
	}
}