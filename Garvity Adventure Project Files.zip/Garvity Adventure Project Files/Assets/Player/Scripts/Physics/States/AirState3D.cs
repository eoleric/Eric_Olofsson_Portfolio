﻿using System;
using UnityEngine;
public struct AirState3D : ICharacterState3D
{
	private const int maxJumpCount = 1;
	private Controller3D controller;
	private readonly Velocity3D velocity;
	private int jumpCount;
    private bool topSide;
    private CollisionFlags currentColFlag;
	private GameObject owner;
	private float hitTime;


	public AirState3D(Controller3D controller, Velocity3D velocity, bool topSide, GameObject owner, bool jumped)	
	{
		if (controller == null)
		{
			throw new ArgumentNullException("controller");
		}
		if (velocity == null)
		{
			throw new ArgumentNullException("velocity");
		}
		this.controller = controller;
		this.velocity = velocity;
		jumpCount = 1;
		if (jumped && !controller.isBox) {
			jumpCount = 0;
		}
		if(jumpCount == 1)
			controller.setFell (true);
        this.topSide = topSide;
        if (topSide)
        {
            currentColFlag = CollisionFlags.Below;
        }
        else
        {
            currentColFlag = CollisionFlags.Above;
        }
		hitTime = 0;
		this.owner = owner;
		if(!controller.isBox)
			controller.setInAir (true); //Sätter animation till true, kopiera denna rad och but ut true till false om du vill stänga av animationen
    }
	public void Enter()
	{
		// Since other states may have worked magic with the gravity we reset it so we start from scratch.
		velocity.SetY(0.0f);
	}
	public void Exit()
	{
		// NOTE: Empty by choice. Here for demonstration purposes.
	}
	public void Update(Vector3 movementInput, float deltaTime)
	{
		controller.CalculateGravity ();
        if (topSide)
        {
            currentColFlag = CollisionFlags.Below;
        }
        else
        {
            currentColFlag = CollisionFlags.Above;
        }
		if (!owner.GetComponent<Controller3D>().isBox) {
			if (ShouldJump ()) {
				PerformJump ();
			} else if (ShouldMinJump ()) {
				PerformMinJump ();
			}
		}
		UpdateVelocity(movementInput, deltaTime);

		if(((Input.GetAxis("Horizontal") > 0) && topSide) || ((Input.GetAxis("Horizontal") < 0) && !topSide))
        {
            controller.getAnim().SetFloat("Speed", -1);
        }
		if(((Input.GetAxis("Horizontal") < 0) && topSide) || ((Input.GetAxis("Horizontal") > 0) && !topSide))
        {
            controller.getAnim().SetFloat("Speed", 1);
        }
        //Debug.Log (velocity.getVelocity().y);
	}
	public CharacterStateSwitch3D HandleCollisions(CollisionFlags collisionFlags)
	{
		RaycastHit hit;

		if (owner.GetComponent<Controller3D> ().isBox) {
			if(Physics.Raycast(new Vector3(owner.transform.position.x -0.41f , owner.transform.position.y , owner.transform.position.z) , Vector3.left, out hit, 0.4f) || Physics.Raycast(new Vector3(owner.transform.position.x -0.41f , owner.transform.position.y + 0.2f, owner.transform.position.z) , Vector3.left, out hit, 0.4f)){
				if (hit.transform.tag == "Player" && Time.time - hitTime > 1f) {
					
					controller.SetTopSide (hit.transform.gameObject.GetComponent<Controller3D>().topSide);
					owner.transform.position = new Vector3 (owner.transform.position.x, hit.transform.gameObject.transform.position.y, owner.transform.position.z);

					UpdateVelocity (Vector3.right * 10, Time.deltaTime);
					velocity.SetY (0f);
					if (controller.topSide) {
						owner.transform.position = new Vector3 (owner.transform.position.x, hit.transform.gameObject.transform.position.y + 0.3f, owner.transform.position.z);
					} else {
						owner.transform.position = new Vector3 (owner.transform.position.x, hit.transform.gameObject.transform.position.y - 0.3f, owner.transform.position.z);
					}
					hitTime = Time.time;
					//owner.transform.Translate (Vector3.right * Time.deltaTime * 50);
				}
			}
			if(Physics.Raycast(new Vector3(owner.transform.position.x + 0.41f , owner.transform.position.y , owner.transform.position.z) , Vector3.right, out hit, 0.4f) || Physics.Raycast(new Vector3(owner.transform.position.x + 0.41f , owner.transform.position.y + 0.2f, owner.transform.position.z) , Vector3.right , out hit, 0.4f)){
				if (hit.transform.tag == "Player" && Time.time - hitTime > 1f) {
					
					controller.SetTopSide (hit.transform.gameObject.GetComponent<Controller3D>().topSide);

					UpdateVelocity (Vector3.left * 10, Time.deltaTime);
					velocity.SetY (0f);
					if (controller.topSide) {
						owner.transform.position = new Vector3 (owner.transform.position.x, hit.transform.gameObject.transform.position.y + 0.3f, owner.transform.position.z);
					} else {
						owner.transform.position = new Vector3 (owner.transform.position.x, hit.transform.gameObject.transform.position.y - 0.3f, owner.transform.position.z);
					}

					hitTime = Time.time;
					//owner.transform.Translate (Vector3.right * Time.deltaTime * 50);
				}
			}
		}

		CharacterStateSwitch3D stateSwitch;
		if ((collisionFlags & currentColFlag) == currentColFlag)
		{
			// Using an arbitrarily distance. If this distance doesn't return true the angle is STEEP.
			if (controller.IsTraversableSlope(controller.ColliderHeight * 10.0f))
			{
				controller.setFell (false);
				controller.setInAir (false);
				controller.setJumped (false);
				stateSwitch = new CharacterStateSwitch3D(new GroundState3D(controller, velocity, topSide, owner));
			}
			else
			{
				controller.setFell (false);
				controller.setInAir (false);
				controller.setJumped (false);
				stateSwitch = new CharacterStateSwitch3D(new SlideState3D(controller, velocity, topSide, owner));
			}
		}
		else
		{
			stateSwitch = new CharacterStateSwitch3D();
		}
		return stateSwitch;
	}
	private void PerformJump()
	{
		controller.setJumped (true);
		++jumpCount;
        if (topSide)
        {
			controller.transform.Translate (Vector3.up * 0.4f);
            velocity.SetY(controller.MaxJumpVelocity);
        }
        else
        {
			controller.transform.Translate (Vector3.down * 0.4f);
            velocity.SetY(-controller.MaxJumpVelocity);
        }
	}
	private void PerformMinJump()
	{
        if (topSide)
        {
            velocity.SetY(controller.MinJumpVelocity);
        }
        else
        {
            velocity.SetY(-controller.MinJumpVelocity);
        }
	}
	private bool ShouldJump()
	{
			return Input.GetButtonDown("Jump") && jumpCount < maxJumpCount;
	}
	private bool ShouldMinJump()
	{


			if (topSide)
			{
				return Input.GetButtonDown("Jump") && velocity.Current.y > controller.MinJumpVelocity;
			}
			else
			{
				return Input.GetButtonDown("Jump") && velocity.Current.y < -controller.MinJumpVelocity;
			}	

	}
	private void UpdateVelocity(Vector3 movementInput, float deltaTime)
	{
		var smoothDampDataX = GetSmoothDampData(movementInput.x);
		var smoothDampDataZ = GetSmoothDampData(movementInput.z);
        velocity.AddY(controller.Gravity * deltaTime);
		velocity.SmoothDampUpdate(movementInput, smoothDampDataX, smoothDampDataZ, deltaTime);
	}
	private SmoothDampData GetSmoothDampData(float input)
	{
		var targetVelocity = input * controller.MoveSpeed;
		var smoothTime = controller.AirAccelerationTime;
		if (Mathf.Abs(input) < MathHelper.FloatEpsilon)
		{
			smoothTime *= controller.AirDeaccelerationScale;
		}
		return new SmoothDampData(targetVelocity, smoothTime);
	}

	public void SetTopSide(bool top){
		topSide = top;
	}

}