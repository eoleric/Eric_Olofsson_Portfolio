﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animations : MonoBehaviour {


	[SerializeField]
	private bool shaking = false;
	//private Vector3 startPos;
	private Vector3 shakePos;

	private Color standardColor;

	//private Renderer rend;

	private bool topSide;
	//private float speedX;
	//private float speedZ;



	public void SetShake(){
		shaking = !shaking;
		if (shaking) {
			gameObject.tag = "Shaking";
		} else {
			gameObject.tag = "Obstacle";
		}
		transform.position = shakePos;
	}
		

	// Use this for initialization
	void Start () {
		//rend = GetComponent<Renderer> ();
		//startPos = transform.position;
		shakePos = transform.position;

		topSide = GetComponent<Controller3D> ().topSide;
		//speedX = GetComponent<Velocity3D> ().getVelocity().x;
		//speedZ = GetComponent<Velocity3D> ().getVelocity().z;
	}


	// Update is called once per frame
	void Update () {
		if (topSide) {
			transform.position = shakePos;
			transform.position = new Vector3(shakePos.x + Random.Range(-0.05f,0.05f),shakePos.y + Random.Range(-0.05f,0.05f),shakePos.z + Random.Range(-0.05f,0.05f));
		}
	}
		

	public void ShakeForTime(){
		StartCoroutine ("ShakeRoutine");
	}

	IEnumerator ShakeRoutine(){
		SetShake ();
		yield return new WaitForSeconds (1f);
		SetShake ();
	}
}