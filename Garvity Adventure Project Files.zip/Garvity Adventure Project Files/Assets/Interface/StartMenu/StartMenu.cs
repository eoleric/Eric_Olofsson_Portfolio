﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class StartMenu : MonoBehaviour {

	public GameObject StartMenuPanel;
	public GameObject MainMenuPanel;
	public GameObject ControlsPanel;
	//public GameObject HighscorePanel;
	public GameObject ExitPanel;
  
	//public Selectable highscoreButton;
	public Selectable StartButton;
	public Selectable exitButton;
	public Selectable noButton;

	void Start () {
		
		StartMenuPanel.SetActive (true);
		ControlsPanel.SetActive (false);
		//HighscorePanel.SetActive (false);
		ExitPanel.SetActive (false);


	}
	

	void Update () {
		
	}

	public void OnSelect(BaseEventData eventData){
		//Debug.Log (highscoreButton + "was selected");
	}

	public void HighscoreSelected(BaseEventData eventData){
		//Debug.Log (highscoreButton + "was selected");
	}

    public void ControlClick() {

		StartMenuPanel.SetActive (false);
		ControlsPanel.SetActive (true);
		//HighscorePanel.SetActive (false);
		ExitPanel.SetActive (false);
      
    }

	public void HighscoreClick (){
		
		StartMenuPanel.SetActive (false);
		ControlsPanel.SetActive (false);
		//HighscorePanel.SetActive (true);
		ExitPanel.SetActive (false);

	}

	public void ExitClick(){
		
		StartMenuPanel.SetActive (false);
		ControlsPanel.SetActive (false);
		//HighscorePanel.SetActive (false);
		ExitPanel.SetActive (true);

		MainMenuPanel.GetComponent<SelectOnInput> ().SetSelcted(noButton.gameObject);
	}

	public void StartMenuClick(){
		
		StartMenuPanel.SetActive (true);
		ControlsPanel.SetActive (false);
		//HighscorePanel.SetActive (false);
		ExitPanel.SetActive (false);

	}

	public void NoExitClick(){
		StartMenuPanel.SetActive (true);
		ControlsPanel.SetActive (false);
		//HighscorePanel.SetActive (false);
		ExitPanel.SetActive (false);

		MainMenuPanel.GetComponent<SelectOnInput> ().SetSelcted(StartButton.gameObject);
	
	}
}
