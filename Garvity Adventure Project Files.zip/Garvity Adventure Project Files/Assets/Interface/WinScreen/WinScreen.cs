﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WinScreen : MonoBehaviour {

	public GameObject WinText;
	private Text deathText;

	public int deaths;

	// Use this for initialization
	void Start () {

		deaths = FindObjectOfType<GameManager> ().getLife ();
		deathText = WinText.GetComponent<Text> ();
	}
	
	// Update is called once per frame
	void Update () {
		FindObjectOfType<GameManager> ().setLife (GameObject.FindGameObjectWithTag("Player").GetComponent<Controller3D>().hearts);
		deaths = FindObjectOfType<GameManager> ().getLife ();
		deathText.text = "You DIED " + deaths + " times";
	}
		
}
