﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CreditScreen : MonoBehaviour {

    private int resetDeaths = 0;
    private int resetLvl = 2;
    private string Name = "name";
    private int deaths;
 

    // Use this for initialization
    void Start()
    {
        deaths = FindObjectOfType<GameManager>().getLife();
    }
	// Update is called once per frame
	void Update () {
        if (Input.anyKeyDown)
        {
            Highscores.AddNewHighscore(Name, deaths);
            FindObjectOfType<GameManager>().setLife(resetDeaths);
            FindObjectOfType<GameManager>().sceneLevel = resetLvl;
            SceneManager.LoadScene(1);
        }
	}
}
