﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleScreen : MonoBehaviour {

	// Use this for initialization
	void Start () {
		StartCoroutine ("GetStarted");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	IEnumerator GetStarted(){
		yield return new WaitForSeconds (8f);
		SceneManager.LoadScene (1);
	}
}
