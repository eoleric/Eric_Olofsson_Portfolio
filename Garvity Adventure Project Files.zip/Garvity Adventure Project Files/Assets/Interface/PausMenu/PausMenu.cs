﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PausMenu : MonoBehaviour {

    public GameObject PausMenuCanvas;
	public GameObject MainCanvas;

	// Use this for initialization
	void Start () {
        PausMenuCanvas.SetActive(false);
	}

    // Update is called once per frame
    void Update()
    {
   
    }


    public void StartPress()
    {
		GameObject.FindGameObjectWithTag ("Player").GetComponent<Controller3D> ().isPaused = false;
		MainCanvas.SetActive (true);
        PausMenuCanvas.SetActive(false);
        Time.timeScale = 1;
    }

    public void HubPress()
    {
        GameObject.FindGameObjectWithTag("Player").GetComponent<Controller3D>().BOXMODEACTIVATE(true);
        Time.timeScale = 1;
        FindObjectOfType<GameManager>().LoadLevel(2);
    }

    public void MainMenuPress()
    {
        GameObject.FindGameObjectWithTag("Player").GetComponent<Controller3D>().BOXMODEACTIVATE(true);
        Time.timeScale = 1;
        FindObjectOfType<GameManager>().LoadLevel(1);
    }

    public void ExitPress()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
