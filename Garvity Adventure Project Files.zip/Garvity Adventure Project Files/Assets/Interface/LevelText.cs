﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class LevelText : MonoBehaviour {

	Scene level;

	// Use this for initialization
	void Start () {
		level = SceneManager.GetActiveScene ();
		string name = level.name;
		GetComponent<Text> ().text = name;
	}
	
	// Update is called once per frame
	void Update () {
	}
}
