﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class BossCoverState : IBossState {

	private readonly Boss controller;
	private readonly Velocity3D velocity;
	private bool topSide;
	private CollisionFlags currentColFlag;
	private GameObject owner;

	private Color normalColor;

	private Color coverColor = Color.red;

	private Renderer rend;

	private float enterTime = 0f;

	public BossCoverState(Boss controller, Velocity3D velocity, bool topSide, GameObject owner)
	{
        
		if (controller == null)
		{
			throw new ArgumentNullException("controller");
		}
		if (velocity == null)
		{
			throw new ArgumentNullException("velocity");
		}
		this.controller = controller;
		this.velocity = velocity;
		this.topSide = topSide;
		if (topSide)
		{
			currentColFlag = CollisionFlags.Below;
		}
		else
		{
			currentColFlag = CollisionFlags.Above;
		}
		this.owner = owner;
		enterTime = Time.time;
	}

	public void Enter()
	{
		// Since other states may have worked magic with the gravity we reset it so we start from scratch.
		velocity.SetY(0.0f);
		GameObject[] blocks = GameObject.FindGameObjectsWithTag ("Obstacle");
		for(int i = 0; i < blocks.Length; i++){
			if (Vector3.Distance (owner.transform.position, blocks [i].transform.position) < 2f) {
				blocks [i].GetComponent<GroundBehaviour> ().ShakeForTime ();
				blocks [i].GetComponent<GroundBehaviour> ().TakeDamage ();
			}
		}
		rend = owner.GetComponent<Boss> ().GetRen ();
		normalColor = rend.material.color;
		rend.material.color = coverColor;
		enterTime = Time.time;
		owner.gameObject.GetComponent<Boss> ().head.SetActive (false);
        owner.gameObject.GetComponent<Boss>().shield.SetActive(true);

    }

	public void Exit()
	{
		rend.material.color = normalColor;
		owner.gameObject.GetComponent<Boss> ().head.SetActive (true);
        owner.gameObject.GetComponent<Boss>().shield.SetActive(false);
    }

	public void Update(GameObject player, float deltaTime)
	{
//		Vector3 distance = CalculateDistance (player);
//		Vector3 direction = CalculateDirection (player);
//		if (distance.x > -2f && distance.x < 2f && topSide != player.GetComponent<Controller3D>().topSide)
//		{
//			var stateSwitch = new BossStateSwitch(new BossAirState(controller, velocity, topSide, owner), direction, deltaTime, true);
//			controller.ChangeCharacterState(stateSwitch);
//		}
//		else
		//		{
		UpdateVelocity(Vector3.zero, deltaTime);
		//}

		if(Time.time - enterTime > 2f){
			
			BossStateSwitch stateSwitch;
			//Vector3 playerdirection = CalculateDirection (player);
			stateSwitch = new BossStateSwitch(new BossGroundState(controller, velocity, topSide, owner));
			controller.ChangeCharacterState(stateSwitch);
		}
	}

	private void UpdateVelocity(Vector3 movementInput, float deltaTime)
	{
		var smoothDampDataX = GetSmoothDampData(movementInput.x);
		var smoothDampDataZ = GetSmoothDampData(0f);
		// Using an arbitrary gravity here that, hopefully, is enough to allow use tomaintain grounded
		// regardless of the slope and speed. This may need to be adjusted depending onthe game.
		// Actually, it may work well with a very big negative number if we alwayschange the y velocity
		// to 0 whenever we switch state. Something to try.
		if (topSide)
		{
			velocity.SetY(-20.0f);
		}
		else
		{
			velocity.SetY(20.0f);
		}
		velocity.SmoothDampUpdate(movementInput, smoothDampDataX, smoothDampDataZ, deltaTime);
	}

	private SmoothDampData GetSmoothDampData(float input)
	{
		var targetVelocity = input * controller.MoveSpeed;
		var smoothTime = controller.GroundAccelerationTime;
		if (Mathf.Abs(input) < MathHelper.FloatEpsilon)
		{
			smoothTime *= controller.GroundDeaccelerationScale;
		}
		return new SmoothDampData(targetVelocity, smoothTime);
	}

	public Vector3 CalculateDirection(GameObject player){
		Vector3 direction = Vector3.zero;
		if (player.transform.position.x > owner.transform.position.x) {
			direction.x = 1;
		} else {
			direction.x = -1;
		}

		return direction;
	}

	private Vector3 CalculateDistance(GameObject player){
		return new Vector3 (owner.transform.position.x - player.transform.position.x, owner.transform.position.y - player.transform.position.y, owner.transform.position.z - player.transform.position.z);
	}

	public BossStateSwitch HandleCollisions(CollisionFlags collisionFlags)
	{

		BossStateSwitch stateSwitch;
		if ((collisionFlags & currentColFlag) == currentColFlag)
		{
			stateSwitch = new BossStateSwitch();
		}
		else
		{
			stateSwitch = new BossStateSwitch(new BossAirState(controller, velocity, topSide, owner));
			controller.ChangeCharacterState(stateSwitch);
		}
		return stateSwitch;
	}

	public void SetTopSide(bool top){
		topSide = top;
	}
}
