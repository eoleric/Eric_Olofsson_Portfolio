﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlocksTrigger : MonoBehaviour {

	public GameObject boss;
	private Boss controller;

	// Use this for initialization
	void Start () {
		controller = boss.GetComponent<Boss> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider other){
		if (other.tag == "Obstacle" && controller.phase2 && (controller.characterState as BossDashState) != null) {
			other.GetComponent<GroundBehaviour> ().ShakeForTime ();
		}
	}

	void OnTriggerStay(Collider other){
		if (other.tag == "Obstacle" && controller.phase3) {
			if(other.GetComponent<GroundBehaviour>().lvl3Ground)
				other.GetComponent<GroundBehaviour> ().ShakeForTime2();
			else
				other.GetComponent<GroundBehaviour> ().TakeDamage ();
		}
	}
}
