﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Boss : MonoBehaviour {

	public bool isNewBoss = false;
	[HideInInspector]
	public bool phase2 = false;

	[HideInInspector]
	public bool phase3 = false;

	public bool topSide = true;
	[HideInInspector]
	public bool startSide;
	[HideInInspector]
	public Vector3 startPos;

	public ParticleSystem deathParticle;

	public Slider healthbar;
	public float healthCounter = 300f;
	public GameObject winText;
    public GameObject shield;
	public GameObject winCanvas;
	public GameObject head1;
	public GameObject head2;
    public MeshRenderer bossMesh;

	private Velocity3D velocity;
	public float TerminalVelocity = 18.0f;
	public float Gravity { get; private set; }
	[Tooltip("The maximum jump height in units")]
	public float MaxJumpHeight = 4.0f;
	[Tooltip("The time it takes (seconds) to reach the maximum jump height")]
	public float TimeToJumpApex = 0.4f;
	[Tooltip("The smallest jump height possible in units")]
	public float MinJumpHeight = 1.0f;
	public float MoveSpeed = 2.0f;
	public float GroundAccelerationTime = 0.1f;
	public float AirAccelerationTime = 0.2f;
	public float GroundDeaccelerationScale = 0.8f;
	public float AirDeaccelerationScale = 3.5f;
	private CharacterController characterController;
	public GameObject head;

	public bool permaJump = false;

	public float MaxJumpVelocity { get; private set; }
	public float MinJumpVelocity { get; private set; }
	[HideInInspector]
	public IBossState characterState;

	private GameObject player;


	private AudioSource source;
	public AudioClip jump;
	public AudioClip land;
	public AudioClip takeDamage;

	public float switchValue = 0f;

	public GameObject[] maze;
	public GameObject[] part2;
	public GameObject[] part3;

	public GameObject targetMark;

	public Renderer GetRen(){
		return GetComponent<Renderer> ();
	}

	void Start(){
		deathParticle.Pause ();
        source = GetComponent<AudioSource> ();
        bossMesh = gameObject.GetComponent<MeshRenderer>();
        bossMesh.enabled = true;
        winCanvas.SetActive (false);
		winText.SetActive (false);
	}

	// Use this for initialization
	private void Awake () {
		startPos = transform.position;
		startSide = topSide;
		CreateVelocity();
		CacheComponents();
		CalculateGravity();
		CalculateJumpVelocities();
		SetInitialCharacterState();
		player = GameObject.FindGameObjectWithTag ("Player");
	}

	public void playJumpSound(){
		source.PlayOneShot (jump);
	}

	public void playLandSound(){
		source.PlayOneShot (land);
	}

	public void moveToLastPos(){
		if (characterState as BossTrackState != null) {
			(characterState as BossTrackState).moveToLastPos ();
		}
	}
	
	// Update is called once per frame
	void Update () {

		var deltaTime = Time.deltaTime;
		characterState.Update(player, deltaTime);
		HandleCollisions(Move());

		if (transform.position.y < switchValue && topSide) {
			SetTopSide ();
			if (velocity.getVelocity ().y > -15f) {
				velocity.SetY (-15f);
			}
		} else if (transform.position.y > switchValue && !topSide) {
			SetTopSide ();
			if (velocity.getVelocity ().y < 15f) {
				velocity.SetY (15f);
			}
		}
	}


	private void CreateVelocity()
	{
		velocity = new Velocity3D(-TerminalVelocity, gameObject);
	}

	public void CalculateGravity()
	{
		if (topSide)
		{
			Gravity = -(2 * MaxJumpHeight) / Mathf.Pow(TimeToJumpApex, 2);
		}
		else
		{
			Gravity = (2 * MaxJumpHeight) / Mathf.Pow(TimeToJumpApex, 2);
		}
	}

	private void CalculateJumpVelocities()
	{
		var positiveGravity = Mathf.Abs(Gravity);
		MaxJumpVelocity = positiveGravity * TimeToJumpApex;
		MinJumpVelocity = Mathf.Sqrt(2 * positiveGravity * MinJumpHeight);
	}

	private CollisionFlags Move()
	{
		// The Move() method of a CharacterController takes a vector in world space. Since the velocity is
		// using local space we need to convert it to world space first.
		var moveDirection = transform.TransformDirection(velocity.Current).normalized;
		var moveLength = velocity.Current.magnitude;
		var motion = moveDirection * moveLength;
		return characterController.Move(motion);
	}

	private void CacheComponents()
	{
		characterController = GetComponent<CharacterController>();
	}

	private void HandleCollisions(CollisionFlags collisionFlags)
	{
		var stateSwitch = characterState.HandleCollisions(collisionFlags);
		if (stateSwitch.NewState != null)
		{
			ChangeCharacterState(stateSwitch);
		}
	}

	public void ChangeCharacterState(BossStateSwitch stateSwitch)
	{
		PrintStateSwitch(stateSwitch);
		characterState.Exit();
		characterState = stateSwitch.NewState;
		characterState.Enter();
		if (stateSwitch.RunImmediately)
		{
			characterState.Update(player, stateSwitch.DeltaTime);
		}
	}

	[System.Diagnostics.Conditional("UNITY_EDITOR")]
	private void PrintStateSwitch(BossStateSwitch stateSwitch)
	{
		print("Switching character state from " + characterState.ToString() + " to " + stateSwitch.NewState.ToString());
	}

	private void SetInitialCharacterState()
	{
		if (!isNewBoss || phase3) {
			if (characterController.isGrounded) { 
				characterState = new BossGroundState (this, velocity, topSide, gameObject);
			} else {

				characterState = new BossAirState (this, velocity, topSide, gameObject);
			}	
		} else {
			characterState = new BossTrackState (this, velocity, topSide, gameObject);
			characterState.Enter ();
		}
	}

	public void SetTopSide(){
		topSide = !topSide;
		characterState.SetTopSide (topSide);
		CalculateGravity ();
		if (topSide) {
			head.transform.localPosition = new Vector3 (0f, 0.5f, 0f);
		} else {
			head.transform.localPosition = new Vector3 (0f, -0.5f, 0f);
		}
	}

	public void SetTopSide(bool side){
		topSide = side;
		characterState.SetTopSide (topSide);
		CalculateGravity ();
		if (topSide) {
			head.transform.localPosition = new Vector3 (0f, 0.5f, 0f);
		} else {
			head.transform.localPosition = new Vector3 (0f, -0.5f, 0f);
		}
	}

	public Velocity3D GetVelocity(){
		return velocity;
	}

	public void Damage(float dmg){
		source.PlayOneShot (takeDamage);
		healthCounter -= dmg;
		if (!(isNewBoss && phase2)) {
			BossStateSwitch stateSwitch;
			stateSwitch = new BossStateSwitch(new BossCoverState(this, velocity, topSide, gameObject));
			ChangeCharacterState(stateSwitch);
		}
		if(healthCounter < 200 && healthCounter > 150){
			MoveSpeed = 3.5f;
		}
		if (healthCounter < 150) {
			player.GetComponent<Controller3D> ().startPos = new Vector3 (11f, -42f, 0f);
			MoveSpeed = 3;
			transform.localScale = new Vector3(4f,4f,1f);
			switchValue = -52f;
			phase2 = false;
			phase3 = true;
			//SetInitialCharacterState ();
			player.GetComponent<Controller3D> ().SetTopSide (true);
			foreach (GameObject g in part2) {
				g.SetActive (false);
			}
			foreach (GameObject g in part3) {
				g.SetActive (true);
			}
		}
		if (healthCounter <= 0) {
			Die ();
		}
		healthbar.value = healthCounter;
	}

	public void Die(){
		Debug.Log ("Die");
		deathParticle.Play ();
		winText.SetActive (true);

		MaxJumpHeight = 0f;
		TimeToJumpApex = 0f;
		MinJumpHeight = 0f;
		MoveSpeed = 0f;
		GroundAccelerationTime = 0f;
		AirAccelerationTime = 0f;
		GroundDeaccelerationScale = 0f;
		AirDeaccelerationScale = 0f;

		StartCoroutine ("DieRoutine");
       // Destroy(gameObject);
	}

	IEnumerator DieRoutine(){
		yield return new WaitForSeconds (5f);
		winText.SetActive (false);
		winCanvas.SetActive (true);
		Destroy(head);
		Destroy (shield);
        bossMesh.enabled = false;
		head1.SetActive (false);
		head2.SetActive (false);
		StartCoroutine ("LoadCredits");
	}

	IEnumerator LoadCredits(){
		yield return new WaitForSeconds (5f);
		winCanvas.SetActive (false);
		SceneManager.LoadScene (7);
	}

	public void SetMaze(bool b){
		foreach (GameObject g in maze) {
			g.SetActive (b);
		}
	}
}
