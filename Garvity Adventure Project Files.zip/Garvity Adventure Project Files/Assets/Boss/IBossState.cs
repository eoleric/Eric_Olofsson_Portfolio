﻿using UnityEngine;
public interface IBossState
{
	void Enter();
	void Update(GameObject player, float deltaTime);
	BossStateSwitch HandleCollisions(CollisionFlags collisionFlags);
	void SetTopSide (bool top);
	void Exit();
}