﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public struct BossAirState : IBossState {

	private const int maxJumpCount = 1;
	private Boss controller;
	private readonly Velocity3D velocity;
	private int jumpCount;
	private bool topSide;
	private CollisionFlags currentColFlag;
	private GameObject owner;
	//private float hitTime;


	public BossAirState(Boss controller, Velocity3D velocity, bool topSide, GameObject owner) {
		if (controller == null)
		{
			throw new ArgumentNullException("controller");
		}
		if (velocity == null)
		{
			throw new ArgumentNullException("velocity");
		}
		this.controller = controller;
		this.velocity = velocity;
		jumpCount = 0;
		this.topSide = topSide;
		if (topSide)
		{
			currentColFlag = CollisionFlags.Below;
		}
		else
		{
			currentColFlag = CollisionFlags.Above;
		}
		this.owner = owner; 
		//hitTime = 0;
	}
	// Use this for initialization
	public void Enter () {
		velocity.SetY (0.0f);
		//Debug.Log ("air");

	}
	
	// Update is called once per frame
	public void Update (GameObject player, float deltaTime) {
		controller.CalculateGravity ();
		if (topSide)
		{
			currentColFlag = CollisionFlags.Below;
		}
		else
		{
			currentColFlag = CollisionFlags.Above;
		}

		if (ShouldJump (player)) {
			PerformJump ();
		}
		UpdateVelocity(CalculateDirection(player), deltaTime);
	}

	private bool ShouldJump(GameObject player)
	{
		Vector3 distance = CalculateDistance (player);
		return (distance.x > -2f && distance.x < 2f && topSide != player.GetComponent<Controller3D>().topSide || controller.permaJump) && jumpCount < maxJumpCount;
	}

	private Vector3 CalculateDistance(GameObject player){
		return new Vector3 (owner.transform.position.x - player.transform.position.x, owner.transform.position.y - player.transform.position.y, owner.transform.position.z - player.transform.position.z);
	}

	public Vector3 CalculateDirection(GameObject player){
		Vector3 direction = Vector3.zero;
		if (player.transform.position.x > owner.transform.position.x) {
			direction.x = 1;
		} else {
			direction.x = -1;
		}

		return direction;


	}

	public void Exit() {
	}

	private void PerformJump()
	{
		++jumpCount;
		if (topSide)
		{
			controller.transform.Translate (Vector3.up * 0.4f);
			velocity.SetY(controller.MaxJumpVelocity);
		}
		else
		{
			controller.transform.Translate (Vector3.down * 0.4f);
			velocity.SetY(-controller.MaxJumpVelocity);
		}
	}

	private void UpdateVelocity(Vector3 movementInput, float deltaTime)
	{
		var smoothDampDataX = GetSmoothDampData(movementInput.x);
		var smoothDampDataZ = GetSmoothDampData(movementInput.z);
		if (velocity.getVelocity ().y < 0 && controller.permaJump && controller.topSide) {
			velocity.AddY(controller.Gravity * deltaTime * 0.3f);
		}else if(velocity.getVelocity ().y > 0 && controller.permaJump && !controller.topSide){
			velocity.AddY(controller.Gravity * deltaTime * 0.3f);
		} else {
			velocity.AddY(controller.Gravity * deltaTime);	
		}

		velocity.SmoothDampUpdate(movementInput, smoothDampDataX, smoothDampDataZ, deltaTime);
	}

	private SmoothDampData GetSmoothDampData(float input)
	{
		var targetVelocity = input * controller.MoveSpeed;
		var smoothTime = controller.AirAccelerationTime;
		if (Mathf.Abs(input) < MathHelper.FloatEpsilon)
		{
			smoothTime *= controller.AirDeaccelerationScale;
		}
		return new SmoothDampData(targetVelocity, smoothTime);
	}

	public void SetTopSide(bool top){
		topSide = top;
	}

	public BossStateSwitch HandleCollisions(CollisionFlags collisionFlags)
	{

		BossStateSwitch stateSwitch;
		if ((collisionFlags & currentColFlag) == currentColFlag)
		{
			owner.GetComponent<Boss> ().playLandSound ();
			if(controller.isNewBoss && controller.phase2)
				stateSwitch = new BossStateSwitch(new BossDashState(controller, velocity, topSide, owner));
			else
				stateSwitch = new BossStateSwitch(new BossGroundState(controller, velocity, topSide, owner));
		}
		else
		{
			stateSwitch = new BossStateSwitch();
		}
		return stateSwitch;
	}
}
