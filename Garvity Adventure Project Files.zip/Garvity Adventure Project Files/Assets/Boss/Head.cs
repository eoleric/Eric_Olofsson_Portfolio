﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Head : MonoBehaviour {

	public GameObject boss;
	private Boss controller;
	private float dmgTime = 0;

	private Controller3D player;

	// Use this for initialization
	void Start () {
		player = GameObject.FindGameObjectWithTag ("Player").GetComponent<Controller3D>();
		controller = boss.GetComponent<Boss> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider other){
		if (other.gameObject.tag == "Player" && Time.time - dmgTime > 1f) {
			if (!(controller.characterState as BossTrackState != null)) {
				if (!(controller.characterState as BossCoverState != null))
					dmgTime = Time.time;
				controller.Damage (20);
				if (player.topSide) {
					player.GetVelocity ().SetY (13f);
				} else {
					player.GetVelocity ().SetY (-13f);
				}
			} else {
				player.Damage (50f);
				controller.moveToLastPos ();
			}
		}
	}
}
