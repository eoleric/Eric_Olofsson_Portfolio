﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class BossTrackState : IBossState {

	private readonly Boss controller;
	private readonly Velocity3D velocity;
	private bool topSide;
	private CollisionFlags currentColFlag;
	//private CollisionFlags damageColFlag;
	private GameObject owner;
	public float speed;
	private float moveSpeed = 5.5f;

	public Vector3[] positions = new Vector3[45];
	public int posCounter = 0;

	private float moveTimer = 0;

	public Camera2D cam;



	public BossTrackState(Boss controller, Velocity3D velocity, bool topSide, GameObject owner)
	{
		if (controller == null)
		{
			throw new ArgumentNullException("controller");
		}
		if (velocity == null)
		{
			throw new ArgumentNullException("velocity");
		}
		this.controller = controller;
		this.velocity = velocity;
		this.topSide = topSide;
		if (topSide)
		{
			currentColFlag = CollisionFlags.Below;
		}
		else
		{
			currentColFlag = CollisionFlags.Above;
		}
		//		if (topSide)
		//		{
		//			damageColFlag = CollisionFlags.Above;
		//		}
		//		else
		//		{
		//			damageColFlag = CollisionFlags.Below;
		//		}
		this.owner = owner;

		cam = GameObject.FindGameObjectWithTag ("MainCamera").GetComponent<Camera2D> ();

		speed = controller.MoveSpeed;

		positions [0] = new Vector3 (-6,6,0);
		positions [1] = new Vector3 (13,6,0);
		positions [2] = new Vector3 (13,4,0);
		positions [3] = new Vector3 (-3,4,0);
		positions [4] = new Vector3 (-3,-1,0);
		positions [5] = new Vector3 (-3,2,0);
		positions [6] = new Vector3 (-1,2,0);
		positions [7] = new Vector3 (-1,1,0);
		positions [8] = new Vector3 (1,1,0);
		positions [9] = new Vector3 (1,-3,0);
		positions [10] = new Vector3 (5,-3,0);
		positions [11] = new Vector3 (5.25f,-2.25f,0);
		positions [12] = new Vector3 (6,-2,0);
		positions [13] = new Vector3 (6,1,0);
		positions [14] = new Vector3 (13,1,0);
		positions [15] = new Vector3 (13,-2,0);
		positions [16] = new Vector3 (9,-2,0);
		positions [17] = new Vector3 (9,-8,0);
		positions [18] = new Vector3 (6,-8,0);
		positions [19] = new Vector3 (6,-7,0);
		positions [20] = new Vector3 (0,-7,0);
		positions [21] = new Vector3 (0,-9,0);
		positions [22] = new Vector3 (-2,-9,0);
		positions [23] = new Vector3 (-2,-11,0);
		positions [24] = new Vector3 (5,-11,0);
		positions [25] = new Vector3 (5,-13,0);
		positions [26] = new Vector3 (8,-13,0);
		positions [27] = new Vector3 (8,-12,0);
		positions [28] = new Vector3 (13,-12,0);
		positions [29] = new Vector3 (13,-9.5f,0);
		positions [30] = new Vector3 (13,-14,0);
		positions [31] = new Vector3 (12,-14,0);
		positions [32] = new Vector3 (12,-16,0);
		positions [33] = new Vector3 (2,-16,0);
		positions [34] = new Vector3 (2,-14,0);
		positions [35] = new Vector3 (-3,-14,0);
		positions [36] = new Vector3 (-3,-16,0);
		positions [37] = new Vector3 (0,-16,0);
		positions [38] = new Vector3 (0,-18,0);
		positions [39] = new Vector3 (-3,-18,0);
		positions [40] = new Vector3 (-3,-20,0);
		positions [41] = new Vector3 (1,-20,0);
		positions [42] = new Vector3 (1,-21,0);
		positions [43] = new Vector3 (3,-21,0);
		positions [44] = new Vector3 (3,-25,0);

	


	}

	public void Enter()
	{
		Debug.Log ("test");
		cam.SetOnlyY ();
		// Since other states may have worked magic with the gravity we reset it so we start from scratch.
		velocity.SetY(0.0f);
		//		GameObject[] blocks = GameObject.FindGameObjectsWithTag ("Obstacle");
		//		for(int i = 0; i < blocks.Length; i++){
		//			if (Vector3.Distance (owner.transform.position, blocks [i].transform.position) < 2f) {
		//				blocks [i].GetComponent<GroundBehaviour> ().ShakeForTime ();
		//				blocks [i].GetComponent<GroundBehaviour> ().TakeDamage ();
		//			}
		//		}
	}

	public void Exit()
	{
		cam.SetOnlyY ();
		// NOTE: Empty by choice. Here for demonstration purposes.
	}

	public void Update(GameObject player, float deltaTime)
	{
//		Vector3 distance = CalculateDistance (player);
//		Vector3 direction = CalculateDirection (player);
//		if ((distance.x > -2f && distance.x < 2f && topSide != player.GetComponent<Controller3D>().topSide) || owner.gameObject.GetComponent<Boss>().permaJump)
//		{
//			owner.GetComponent<Boss> ().playJumpSound ();
//			var stateSwitch = new BossStateSwitch(new BossAirState(controller, velocity, topSide, owner), direction, deltaTime, true);
//			controller.ChangeCharacterState(stateSwitch);
//		}
//		else
//		{
//			UpdateVelocity(direction, deltaTime);
//		}

		if (controller.gameObject.transform.position != positions [posCounter]) {
			controller.gameObject.transform.position = Vector3.MoveTowards (controller.gameObject.transform.position, positions[posCounter], moveSpeed * deltaTime);
			//Vector3 direction = CalculateDirection (positions [posCounter]);
			//UpdateVelocity (Vector3.zero, deltaTime);
		} else {
			if (positions.Length - 1 > posCounter)
				posCounter++;
			else {
				ExitState ();
			}
		}

		if (posCounter == 5) {
			moveSpeed = 8f;
		}

		if (topSide)
		{
			currentColFlag = CollisionFlags.Below;
		}
		else
		{
			currentColFlag = CollisionFlags.Above;
		}


		//		if (topSide)
		//		{
		//			damageColFlag = CollisionFlags.Above;
		//		}
		//		else
		//		{
		//			damageColFlag = CollisionFlags.Below;
		//		}
	}

	private void UpdateVelocity(Vector3 movementInput, float deltaTime)
	{
		var smoothDampDataX = GetSmoothDampData(0f);
		var smoothDampDataZ = GetSmoothDampData(0f);
		// Using an arbitrary gravity here that, hopefully, is enough to allow use tomaintain grounded
		// regardless of the slope and speed. This may need to be adjusted depending onthe game.
		// Actually, it may work well with a very big negative number if we alwayschange the y velocity
		// to 0 whenever we switch state. Something to try.
		velocity.SetY(0f);
//		if (topSide)
//		{
//			velocity.SetY(-20.0f);
//		}
//		else
//		{
//			velocity.SetY(20.0f);
//		}
		velocity.SmoothDampUpdate(movementInput, smoothDampDataX, smoothDampDataZ, deltaTime);
	}

	private SmoothDampData GetSmoothDampData(float input)
	{
		var targetVelocity = input * controller.MoveSpeed;
		var smoothTime = controller.GroundAccelerationTime;
		if (Mathf.Abs(input) < MathHelper.FloatEpsilon)
		{
			smoothTime *= controller.GroundDeaccelerationScale;
		}
		return new SmoothDampData(targetVelocity, smoothTime);
	}

	public Vector3 CalculateDirection(Vector3 pos){
		Vector3 direction = Vector3.zero;
		if (pos.x > owner.transform.position.x) {
			direction.x = 1;
		} else {
			direction.x = -1;
		}

		if (pos.y > owner.transform.position.y) {
			direction.y = 1;
		} else {
			direction.y = -1;
		}

		return direction;
	}

	private Vector3 CalculateDistance(GameObject player){
		return new Vector3 (owner.transform.position.x - player.transform.position.x, owner.transform.position.y - player.transform.position.y, owner.transform.position.z - player.transform.position.z);
	}

	public BossStateSwitch HandleCollisions(CollisionFlags collisionFlags)
	{
		//		RaycastHit hit;
		//		if (owner.GetComponent<Controller3D> ().isBox) {
		//			if(Physics.Raycast(new Vector3(owner.transform.position.x -0.41f , owner.transform.position.y - 0.2f, owner.transform.position.z) , Vector3.left, out hit, 0.1f) || Physics.Raycast(new Vector3(owner.transform.position.x -0.41f , owner.transform.position.y + 0.2f, owner.transform.position.z) , Vector3.left, out hit, 0.1f)){
		//				if (hit.transform.tag == "Player") {
		//					owner.transform.Translate (Vector3.right * Time.deltaTime * 2);
		//				}
		//			}
		//			if(Physics.Raycast(new Vector3(owner.transform.position.x + 0.41f , owner.transform.position.y - 0.2f, owner.transform.position.z) , Vector3.right, out hit, 0.1f) || Physics.Raycast(new Vector3(owner.transform.position.x + 0.41f , owner.transform.position.y + 0.2f, owner.transform.position.z) , Vector3.right , out hit, 0.1f)){
		//				if (hit.transform.tag == "Player") {
		//					owner.transform.Translate (Vector3.left * Time.deltaTime * 2);
		//				}
		//			}
		//		}

		BossStateSwitch stateSwitch;
//		if ((collisionFlags & currentColFlag) == currentColFlag)
//		{
			stateSwitch = new BossStateSwitch();
//		}
//		else
//		{
//			stateSwitch = new BossStateSwitch(new BossAirState(controller, velocity, topSide, owner));
//			controller.ChangeCharacterState(stateSwitch);
//		}
		//Debug.Log ("STATE: AIR");
		return stateSwitch;
	}

	public void SetTopSide(bool top){
		topSide = top;

	}

	public void moveToLastPos(){
		if (Time.time - moveTimer > 0.5f) {
			posCounter -= 1;
			if (posCounter < 0)
				posCounter = 0;
			moveTimer = Time.time;
		}
	}

	public void resetTrack(){
		posCounter = 0;
		moveSpeed = 5.5f;
		controller.transform.position = positions [posCounter];
	}

	public void ExitState(){
		controller.SetMaze (false);
		controller.transform.localScale = new Vector3 (3.5f,3.5f,1f);
		controller.switchValue = -32f;
		controller.phase2 = true;
		cam.ResetCamera ();
		BossStateSwitch stateSwitch;
		stateSwitch = new BossStateSwitch(new BossAirState(controller, velocity, true, owner));
		controller.ChangeCharacterState(stateSwitch);
	}
}
