﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class BossSlideState :  IBossState {

	private readonly Boss controller;
	private readonly Velocity3D velocity;
	private bool topSide;
	private CollisionFlags currentColFlag;
	//private CollisionFlags damageColFlag;
	private GameObject owner;

	private Vector3 target;

	public bool aim = true;

	public BossSlideState(Boss controller, Velocity3D velocity, bool topSide, GameObject owner)
	{
		if (controller == null)
		{
			throw new ArgumentNullException("controller");
		}
		if (velocity == null)
		{
			throw new ArgumentNullException("velocity");
		}
		this.controller = controller;
		this.velocity = velocity;
		this.topSide = topSide;
		if (topSide)
		{
			currentColFlag = CollisionFlags.Below;
		}
		else
		{
			currentColFlag = CollisionFlags.Above;
		}
		//		if (topSide)
		//		{
		//			damageColFlag = CollisionFlags.Above;
		//		}
		//		else
		//		{
		//			damageColFlag = CollisionFlags.Below;
		//		}
		this.owner = owner;


	}

	public void Enter()
	{
		// Since other states may have worked magic with the gravity we reset it so we start from scratch.
		velocity.SetY(0.0f);
		//		GameObject[] blocks = GameObject.FindGameObjectsWithTag ("Obstacle");
		//		for(int i = 0; i < blocks.Length; i++){
		//			if (Vector3.Distance (owner.transform.position, blocks [i].transform.position) < 2f) {
		//				blocks [i].GetComponent<GroundBehaviour> ().ShakeForTime ();
		//				blocks [i].GetComponent<GroundBehaviour> ().TakeDamage ();
		//			}
		//		}
	}

	public void Exit()
	{
		// NOTE: Empty by choice. Here for demonstration purposes.
	}

	public void Update(GameObject player, float deltaTime)
	{
//		Vector3 distance = CalculateDistance (player);
//		Vector3 direction = CalculateDirection (player);

		if (aim) {
			UpdateVelocity (Vector3.zero, deltaTime);
		} else {
			if (owner.transform.position == target) {
				StartAim ();
			} else {
				Vector3 direction = CalculateDirection (target);
				UpdateVelocity(direction, deltaTime);
			}
		}


		
		if (topSide)
		{
			currentColFlag = CollisionFlags.Below;
		}
		else
		{
			currentColFlag = CollisionFlags.Above;
		}
		//		if (topSide)
		//		{
		//			damageColFlag = CollisionFlags.Above;
		//		}
		//		else
		//		{
		//			damageColFlag = CollisionFlags.Below;
		//		}
	}

	private void UpdateVelocity(Vector3 movementInput, float deltaTime)
	{
		var smoothDampDataX = GetSmoothDampData(movementInput.x);
		var smoothDampDataZ = GetSmoothDampData(0f);
		// Using an arbitrary gravity here that, hopefully, is enough to allow use tomaintain grounded
		// regardless of the slope and speed. This may need to be adjusted depending onthe game.
		// Actually, it may work well with a very big negative number if we alwayschange the y velocity
		// to 0 whenever we switch state. Something to try.
		if (topSide)
		{
			velocity.SetY(-20.0f);
		}
		else
		{
			velocity.SetY(20.0f);
		}
		velocity.SmoothDampUpdate(movementInput, smoothDampDataX, smoothDampDataZ, deltaTime);
	}

	private SmoothDampData GetSmoothDampData(float input)
	{
		var targetVelocity = input * controller.MoveSpeed * 5f;
		var smoothTime = controller.GroundAccelerationTime;
		if (Mathf.Abs(input) < MathHelper.FloatEpsilon)
		{
			smoothTime *= controller.GroundDeaccelerationScale;
		}
		return new SmoothDampData(targetVelocity, smoothTime);
	}

	public Vector3 CalculateDirection(Vector3 player){
		Vector3 direction = Vector3.zero;
		if (player.x > owner.transform.position.x) {
			direction.x = 1;
		} else {
			direction.x = -1;
		}

		return direction;
	}

	private Vector3 CalculateDistance(GameObject player){
		return new Vector3 (owner.transform.position.x - player.transform.position.x, owner.transform.position.y - player.transform.position.y, owner.transform.position.z - player.transform.position.z);
	}

	public BossStateSwitch HandleCollisions(CollisionFlags collisionFlags)
	{
		//		RaycastHit hit;
		//		if (owner.GetComponent<Controller3D> ().isBox) {
		//			if(Physics.Raycast(new Vector3(owner.transform.position.x -0.41f , owner.transform.position.y - 0.2f, owner.transform.position.z) , Vector3.left, out hit, 0.1f) || Physics.Raycast(new Vector3(owner.transform.position.x -0.41f , owner.transform.position.y + 0.2f, owner.transform.position.z) , Vector3.left, out hit, 0.1f)){
		//				if (hit.transform.tag == "Player") {
		//					owner.transform.Translate (Vector3.right * Time.deltaTime * 2);
		//				}
		//			}
		//			if(Physics.Raycast(new Vector3(owner.transform.position.x + 0.41f , owner.transform.position.y - 0.2f, owner.transform.position.z) , Vector3.right, out hit, 0.1f) || Physics.Raycast(new Vector3(owner.transform.position.x + 0.41f , owner.transform.position.y + 0.2f, owner.transform.position.z) , Vector3.right , out hit, 0.1f)){
		//				if (hit.transform.tag == "Player") {
		//					owner.transform.Translate (Vector3.left * Time.deltaTime * 2);
		//				}
		//			}
		//		}

		BossStateSwitch stateSwitch;
//		if ((collisionFlags & currentColFlag) == currentColFlag)
//		{
			stateSwitch = new BossStateSwitch();
//		}
//		else
//		{
//			stateSwitch = new BossStateSwitch(new BossAirState(controller, velocity, topSide, owner));
//			controller.ChangeCharacterState(stateSwitch);
//		}
		//Debug.Log ("STATE: AIR");
		return stateSwitch;
	}

	public void SetTopSide(bool top){
		topSide = top;

	}

	public void StartAim(){
		aim = true;
		//StartCoroutine ("aimRoutine");
	}

//	public IEnumerator aimRoutine(){
//		yield return new WaitForSeconds (3f);
//		target = GameObject.FindGameObjectWithTag ("Player").transform.position;
//		aim = false;
//	}
}
