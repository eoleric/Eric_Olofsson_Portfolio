﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SidesDamage : MonoBehaviour {

	public GameObject boss;
	private Boss controller;

	private Controller3D player;

	// Use this for initialization
	void Start () {
		player = GameObject.FindGameObjectWithTag ("Player").GetComponent<Controller3D>();
		controller = boss.GetComponent<Boss> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerStay(Collider other){
		if (other.gameObject.tag == "Player") {
			if (!(controller.characterState as BossTrackState != null)) {
				player.Damage (60 * Time.deltaTime);
			} else {
				player.Damage (1000 * Time.deltaTime);
				controller.moveToLastPos ();
			}
		}
	}
}
