﻿using UnityEngine;
public struct BossStateSwitch
{
	private readonly IBossState newState;
	private readonly Vector3 movementInput;
	private readonly float deltaTime;
	private readonly bool runImmediately;

	public BossStateSwitch(IBossState newState) : this(newState, Vector3.zero, 0.0f, false)
	{ }

	public BossStateSwitch(IBossState newState, Vector3 movementInput, float deltaTime, bool runImmediately)
	{
		this.newState = newState;
		this.movementInput = movementInput;
		this.deltaTime = deltaTime;
		this.runImmediately = runImmediately;
	}
	/// <summary>
	/// The new state, if any.
	/// </summary>
	public IBossState NewState
	{
		get { return newState; }
	}
	/// <summary>
	/// The movement input vector to use for the new state.
	/// </summary>
	public Vector3 MovementInput
	{
		get { return movementInput; }
	}
	/// <summary>
	/// The delta time to use for the new state.
	/// </summary>
	public float DeltaTime
	{
		get { return deltaTime; }
	}

	/// <summary>
	/// True if the new state should be run in the same update.
	/// </summary>
	public bool RunImmediately
	{
		get { return runImmediately; }
	}
}