﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;


public class MainSelect : EventTrigger {

	GameObject[] hide;
	GameObject[] hide2;
	GameObject[] hide3;
	GameObject[] hide4;
	GameObject[] hide5;


	// Use this for initialization
	void Awake () {
		hide = GameObject.FindGameObjectsWithTag ("Play");
		hide2 = GameObject.FindGameObjectsWithTag ("HUB");
		hide3 = GameObject.FindGameObjectsWithTag ("Main");
		hide4 = GameObject.FindGameObjectsWithTag ("Exit");
		hide5 = GameObject.FindGameObjectsWithTag ("Controls");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public override void OnSelect(BaseEventData data)
	{
		

		foreach (GameObject g in hide) {
			g.SetActive (false);
		}

		foreach (GameObject g in hide2) {
			g.SetActive (false);
		}

		foreach (GameObject g in hide3) {
			g.SetActive (true);
		}

		foreach (GameObject g in hide4) {
			g.SetActive (false);
		}

		foreach (GameObject g in hide5) {
			g.SetActive (true);
		}
	}
}
