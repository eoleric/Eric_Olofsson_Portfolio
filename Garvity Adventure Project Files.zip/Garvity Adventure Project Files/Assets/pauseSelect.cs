﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class pauseSelect : MonoBehaviour {

	public GameObject[] PlaySelect;

	public GameObject[] HubSelect;

	public GameObject[] MainSelect;

	public GameObject[] ExitSelect;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void EnterExit(){
		foreach (GameObject g in ExitSelect) {
			g.SetActive (true);
		}
	}

	public void ExitExit(){
		foreach (GameObject g in ExitSelect) {
			g.SetActive (false);
		}
	}

	public void EnterPlay(){
		foreach (GameObject g in PlaySelect) {
			g.SetActive (true);
		}
	}

	public void ExitPlay(){
		foreach (GameObject g in PlaySelect) {
			g.SetActive (false);
		}
	}

	public void EnterHub(){
		foreach (GameObject g in HubSelect) {
			g.SetActive (true);
		}
	}

	public void ExitHub(){
		foreach (GameObject g in HubSelect) {
			g.SetActive (false);
		}
	}

	public void EnterMain(){
		foreach (GameObject g in MainSelect) {
			g.SetActive (true);
		}
	}

	public void ExitMain(){
		foreach (GameObject g in MainSelect) {
			g.SetActive (false);
		}
	}
}
