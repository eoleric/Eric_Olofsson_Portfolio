﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class miniBossDive : miniBossState {

	private Vector3 target;
	private miniBoss controller;
	private Vector3 direction;
	private float speed = 7f;
	private bool canHurt = true;

	private float damageTime = 0;

	private float enterTime = 0;

	public miniBossDive(GameObject owner, GameObject player) : base(owner){
		target = player.transform.position;
		controller = base.owner.GetComponent<miniBoss> ();
		direction = (target - owner.transform.position).normalized;
		enterTime = Time.time;
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public override void getMovement(){

		if (Time.time - damageTime > 1f) {
			controller.color (false);
		} else {
			controller.color (true);
		}

		if(Time.time - enterTime > 0.8f)
			owner.transform.Translate (speed * direction * Time.deltaTime);
		//owner.transform.position = Vector3.MoveTowards ( owner.transform.position, target,  5f * Time.deltaTime);
		if (Vector3.Distance(base.owner.transform.position, target) > 15f) {
			controller.enterPatrol ();
		}
	}

	public override void hitHead(Collider other){
		if (Time.time - damageTime > 1f && other.gameObject.tag == "Player") {
			controller.damage (50);
			damageTime = Time.time;
		}
		//controller.enterPatrol ();
	}

	public override void hitSides(Collider other){
		if (other.gameObject.tag == "Obstacle") {
			GameObject[] grounds = GameObject.FindGameObjectsWithTag ("Obstacle");
			foreach (GameObject g in grounds) {
				if(Vector3.Distance(g.transform.position, base.owner.transform.position) < 2f){
					g.gameObject.GetComponent<GroundBehaviour> ().TakeDamage ();
					g.gameObject.GetComponent<GroundBehaviour> ().TakeDamage ();
				}
			}
		}else if(other.gameObject.tag == "Player" && canHurt){
			canHurt = false;
			other.gameObject.GetComponent<Controller3D> ().Damage (25);
		}
		controller.enterPatrol ();
	}
}
