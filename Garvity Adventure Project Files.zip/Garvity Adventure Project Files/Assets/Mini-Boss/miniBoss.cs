﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class miniBoss : MonoBehaviour {

	private miniBossState curState;
	public GameObject Player;
	private Controller3D controller;
	public GameObject head;
	public GameObject sides;
	public GameObject door;
	public bool topSide;
	private Renderer rend;
    private bool dead;

	public Camera2D mainCam;
	//private Color standardColor;

	public Slider healthbar;

	public Color damagedColor;

	public GameObject shield;

	public GameObject Key;

    private AudioSource[] sources;
	private AudioSource source1;
	private AudioSource source2;
    public AudioClip dmgSound;
	public AudioClip swoosh;

	private float maxPitch = 1.3f;
	private float minPitch = 0.8f;


    public ParticleSystem PickupPartSys; 


	public float health = 400;

	// Use this for initialization
	void Start () {
        dead = false;
        PickupPartSys.Stop();
		controller = Player.GetComponent<Controller3D> ();
		curState = new miniBossIdle (gameObject);
		topSide = true;
		rend = GetComponent<Renderer> ();
		//standardColor = rend.material.color;
        sources = GetComponents<AudioSource>();
		source1 = sources [0];
		source2 = sources [1];
		source2.pitch = Random.Range (minPitch, maxPitch);
	}
	
	// Update is called once per frame
	void Update () {
		if(controller.topSide != topSide){
			FlipHead ();
			topSide = controller.topSide;
		}
		healthbar.value = health;
		curState.getMovement ();
	}

	public void FlipHead(){
		head.transform.localPosition *= -1;
		sides.transform.localPosition *= -1;
	}

	public void hitHead(Collider other){
		if (other.gameObject.tag == "Player") {
            source1.PlayOneShot(dmgSound);
			if (controller.topSide)
				controller.GetVelocity ().SetY (20f);
			else
				controller.GetVelocity ().SetY (-20f);
		}
		curState.hitHead (other);
	}

	public void hitSides(Collider other){
		curState.hitSides (other);
	}

	public void damage(float dmg){
		health -= dmg;
		if (health <= 0) {
			//Destroy (door);
            //Key.GetComponent<Renderer>().enabled = true;
            //Key.GetComponent<BoxCollider>().enabled= true;
            //PickupPartSys.Play();
			//mainCam.UnlockCam ();
			Destroy(healthbar.gameObject);
            StartCoroutine("miniBossDefeated");
        }
	}

    public IEnumerator miniBossDefeated()
    {
        dead = true;
        GetComponent<Renderer>().enabled = false;
        GetComponent<BoxCollider>().enabled = false;
		head.SetActive (false);
        Key.GetComponent<Renderer>().enabled = true;
        Key.GetComponent<BoxCollider>().enabled = true;
        PickupPartSys.Play();
        yield return new WaitForSeconds(2);
        PickupPartSys.Stop();
        yield return new WaitForSeconds(1);
        mainCam.UnlockCam();
		gameObject.SetActive (false);
        //Destroy(gameObject);
    }

	public void enterDive(){
		curState = new miniBossDive (gameObject, Player);
		source2.PlayOneShot (swoosh);
		source2.pitch = Random.Range (minPitch, maxPitch);
	}

	public void enterPatrol(){
		curState = new miniBossPatrol (gameObject, Player);
		source2.PlayOneShot (swoosh);
		source2.pitch = Random.Range (minPitch, maxPitch);
	}

	public void color(bool dmg){
        if (!dead)
        {
            if (dmg)
            {
                shield.SetActive(true);
                //rend.material.color = damagedColor;
            }
            else
            {
                shield.SetActive(false);
                //rend.material.color = standardColor;
            }
        } else
        {
            return;
        }
	}

	public void activateSlider(){
		healthbar.gameObject.SetActive (true);
		mainCam.LockCamToPoint (new Vector3(101f, 4.3f, -26f));
	}

	public void moveBox(int pos){
		curState.moveBox (pos);
	}
}
