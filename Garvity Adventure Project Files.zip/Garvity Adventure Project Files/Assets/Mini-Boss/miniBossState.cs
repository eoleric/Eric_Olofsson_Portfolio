﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class miniBossState {

	public GameObject owner;

	public miniBossState(GameObject owner){
		this.owner = owner;
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public virtual void getMovement(){
		
	}

	public virtual void hitHead(Collider other){
	}

	public virtual void hitSides(Collider other){
	}

	public virtual void moveBox(int pos){
		
	}
}
