﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class miniBossIdle : miniBossState {

	private Vector3 positions1 = new Vector3 (0f,1.5f,0.5f);
	private Vector3 positions2 = new Vector3 (66.5f,2.5f,0.5f);
	private Vector3 positions3 = new Vector3 (94.5f,9.5f,0.5f);
	private int placeCounter = 1;
	private float damageTime = 0;
	private bool canHurt = true;
	private float hurtTime = 0;


	public miniBossIdle(GameObject owner) : base(owner){
		
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public override void getMovement(){
		if(Time.time - hurtTime > 0.5f && !canHurt){
			canHurt = true;
		}

		if(placeCounter == 1)
			base.owner.transform.position = Vector3.MoveTowards(base.owner.transform.position, positions1, 20 * Time.deltaTime);
		if(placeCounter == 2)
			base.owner.transform.position = Vector3.MoveTowards(base.owner.transform.position, positions2, 20 * Time.deltaTime);
		if(placeCounter == 3)
			base.owner.transform.position = Vector3.MoveTowards(base.owner.transform.position, positions3, 20 * Time.deltaTime);
		if (placeCounter == 4) {
			//base.owner.GetComponent<miniBoss>().bla bla byt bla till spela ljud
			base.owner.GetComponent<miniBoss> ().activateSlider ();
			base.owner.GetComponent<miniBoss> ().enterPatrol ();
		}
	}

	public override void hitHead(Collider other){
		if (Time.time - damageTime > 1f && other.gameObject.tag == "Player") {
			placeCounter++;
			//GetComponent<BoxCollider> ().enabled = false;
			damageTime = Time.time;
		}
	}

	public override void moveBox(int pos){
		if (pos > placeCounter) {
			placeCounter = pos;
		}
	}

	public override void hitSides(Collider other){
		if(other.gameObject.tag == "Player" && canHurt){
			hurtTime = Time.time;
			canHurt = false;
			other.gameObject.GetComponent<Controller3D> ().Damage (25);
		}
	}
}
