﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class miniBossPatrol : miniBossState {

	private miniBoss controller;
	private GameObject Player;
	private Vector3 target;
	private float speed = 9f;
	private Vector3 direction;
	private bool canHurt = true;
	//private bool beenHurt = false;

	private float damageTime = 0;


	public miniBossPatrol(GameObject owner, GameObject Player) : base(owner){
		controller = base.owner.GetComponent<miniBoss> ();

		this.Player = Player;
		int pos = Random.Range (-1, 2);
		if (controller.topSide) {
			target = new Vector3 (Player.transform.position.x + (8f * pos), Player.transform.position.y + 10, Player.transform.position.z);
		} else {
			target = new Vector3 (Player.transform.position.x + (8f * pos), Player.transform.position.y - 10, Player.transform.position.z);
		}

		direction = (target - owner.transform.position).normalized;
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public override void getMovement(){
		if (Time.time - damageTime > 1f) {
			controller.color (false);
		} else {
			controller.color (true);
		}

		owner.transform.Translate (speed * direction * Time.deltaTime);
		//owner.transform.position = Vector3.MoveTowards ( owner.transform.position, target,  5f * Time.deltaTime);
		if (Vector3.Distance(base.owner.transform.position, target) < 5f) {
			controller.enterDive ();
		}
	}

	public override void hitHead(Collider other){
		if (Time.time - damageTime > 1f && other.gameObject.tag == "Player") {
			controller.damage (50);
			damageTime = Time.time;
		}

//		if(!beenHurt){
//			beenHurt = true;
//			target = target + new Vector3(10,0,0);
//			speed += 3;
//			Debug.Log (target);
//		}
	}

	public override void hitSides(Collider other){
		if(other.gameObject.tag == "Player" && canHurt){
			canHurt = false;
			other.gameObject.GetComponent<Controller3D> ().Damage (25);
		}
	}
}
