﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class miniBossDefeat : miniBossState {

	private GameObject player;

	public miniBossDefeat(GameObject owner, GameObject player) : base(owner){
		this.player = player;
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
