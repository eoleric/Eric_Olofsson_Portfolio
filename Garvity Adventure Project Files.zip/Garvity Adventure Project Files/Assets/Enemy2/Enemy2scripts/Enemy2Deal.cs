﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2Deal : Enemy2State {

	private Vector3 placeToBe;

	private bool goingUp = true;

	private Vector3 startPos;

	private bool topSide;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
	}

	public Enemy2Deal(GameObject player): base(player){
		startPos = base.getEnemy ().transform.position;
		//topSide = GameObject.FindGameObjectWithTag ("Player").GetComponent<Controller3D> ().topSide;
		if (GameObject.FindGameObjectWithTag ("Player").transform.position.y < player.transform.position.y) {
			topSide = false;
		} else {
			topSide = true;
		}
	}

	public override Vector3 GetMovement (Vector3 position){
		base.getEnemy ().GetComponent<enemy2> ().stepTime = 4f;
		Vector3 returnVec = position;
		if (topSide) {
			if (goingUp) {
				if (position.y >= startPos.y + 0.5f) {
					goingUp = false;
					returnVec = new Vector3 (position.x, position.y - 0.5f, position.z);
				} else {
					returnVec = new Vector3 (position.x, position.y + 0.5f, position.z);
				}
			} else {
				base.getEnemy ().GetComponent<enemy2> ().stepTime = 2f;
				returnVec = new Vector3 (position.x, position.y - 0.5f, position.z);
			}

			if (returnVec.y < startPos.y) {
				returnVec = startPos;
				base.getEnemy ().GetComponent<enemy2> ().curState = new Enemy2Patrol (base.getEnemy ());
			}
		} else {
			if (goingUp) {
				if (position.y <= startPos.y - 0.5f) {
					goingUp = false;
					returnVec = new Vector3 (position.x, position.y + 0.5f, position.z);
				} else {
					returnVec = new Vector3 (position.x, position.y - 0.5f, position.z);
				}
			} else {
				base.getEnemy ().GetComponent<enemy2> ().stepTime = 2f;
				returnVec = new Vector3 (position.x, position.y + 0.5f, position.z);
			}

			if (returnVec.y > startPos.y) {
				returnVec = startPos;
				base.getEnemy ().GetComponent<enemy2> ().stepTime = 2f;
				base.getEnemy ().GetComponent<enemy2> ().curState = new Enemy2Patrol (base.getEnemy ());
			}
		}


		return returnVec;
	}



	public override void CalculateShake(){
//		if (!base.getEnemy ().GetComponent<enemy2> ().shaking) {
//			base.getEnemy ().GetComponent<enemy2> ().StartShake ();
//		}
	}
}