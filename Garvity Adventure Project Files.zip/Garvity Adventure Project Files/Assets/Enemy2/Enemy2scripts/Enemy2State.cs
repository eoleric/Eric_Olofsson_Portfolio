﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2State {

	private GameObject enemy2;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public Enemy2State(GameObject enemy){
		enemy2 = enemy;
	}

	public virtual Vector3 GetMovement (Vector3 position){
		return Vector3.zero;
	}

	public GameObject getEnemy(){
		return enemy2;
	}

	public virtual void CalculateShake(){
		if (enemy2.GetComponent<enemy2> ().shaking) {
			enemy2.GetComponent<enemy2> ().StartShake ();
		}
	}
}
