﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy2Defeat : Enemy2State {

	public enemy2Defeat(GameObject player): base(player){
		base.getEnemy ().GetComponent<enemy2> ().taBort ();
	}

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

	}

	public override Vector3 GetMovement (Vector3 position){
		base.getEnemy ().GetComponent<enemy2> ().taBort ();
		return position;
	}
}