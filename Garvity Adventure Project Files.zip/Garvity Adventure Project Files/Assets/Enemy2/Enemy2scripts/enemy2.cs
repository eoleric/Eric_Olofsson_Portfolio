﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy2 : MonoBehaviour {

	public Enemy2State curState;

	private Dictionary<Vector3, GameObject> allBlocksTable = new Dictionary<Vector3, GameObject>();

	public Vector3 curPos;

	public float stepTime = 2f;

	public bool shaking = false;

//	public GameObject lastPos;

	public float timer = 0;

	private AudioSource source;
//
	public AudioClip deathClip;

	private bool deamDmg = true;

	private Vector3 startPos;

	// Use this for initialization
	void Start () {
		startPos = transform.localPosition;
		source = GetComponent<AudioSource> ();
		GameObject[] blocks = GameObject.FindGameObjectsWithTag ("Obstacle");
		for(int i = 0; i < blocks.Length; i++){
			allBlocksTable.Add (blocks[i].transform.position, blocks[i]);
		}
//		GameObject temp;
//		allBlocksTable.TryGetValue (transform.position, out temp);
//		lastPos = temp;
		curPos = transform.position;
		curState = new Enemy2Idle (gameObject);
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		timer += Time.deltaTime;
//		if (curState as Enemy2Deal == null) {
//			stepTime = 2f;
//		}

		if (timer > stepTime) {
			HandleMovement ();
			curState.CalculateShake ();
			timer = 0f;
		}

//		if (curState as Enemy2Deal != null) {
//			stepTime = 4f;
//		}
	}

	public List<GameObject> findCloseBlocks(){

		List<GameObject> closeBlocks = new List<GameObject>();

		GameObject temp;

		if (allBlocksTable.TryGetValue(new Vector3(transform.position.x + 1, transform.position.y, transform.position.z), out temp)) {
			//if(Vector3.Distance(temp.transform.position, lastPos.transform.position) > 0.1f)
				closeBlocks.Add(temp);
		}
		if (allBlocksTable.TryGetValue(new Vector3(transform.position.x - 1, transform.position.y, transform.position.z), out temp)) {
			//if(Vector3.Distance(temp.transform.position, lastPos.transform.position) > 0.1f)
				closeBlocks.Add(temp);
		}
		if (allBlocksTable.TryGetValue(new Vector3(transform.position.x, transform.position.y, transform.position.z + 1), out temp)) {
			//if(Vector3.Distance(temp.transform.position, lastPos.transform.position) > 0.1f)
				closeBlocks.Add(temp);
		}
		if (allBlocksTable.TryGetValue(new Vector3(transform.position.x, transform.position.y, transform.position.z - 1), out temp)) {
			//if(Vector3.Distance(temp.transform.position, lastPos.transform.position) > 0.1f)
				closeBlocks.Add(temp);
		}
		return closeBlocks;
	}

	public List<GameObject> findWaveBlocks(int distance){

		List<GameObject> closeBlocks = new List<GameObject>();

		GameObject temp;
		for(int i = -distance; i < -distance + distance * 2 + 1; i++){
			if (allBlocksTable.TryGetValue(new Vector3(transform.position.x + i, transform.position.y, transform.position.z + distance), out temp)) {
				closeBlocks.Add(temp);
			}
			if (allBlocksTable.TryGetValue(new Vector3(transform.position.x + i, transform.position.y, transform.position.z - distance), out temp)) {
				closeBlocks.Add(temp);
			}
		}

		if (distance == 1) {
			if (allBlocksTable.TryGetValue (new Vector3 (transform.position.x + 1, transform.position.y, transform.position.z), out temp)) {
				closeBlocks.Add (temp);
			}
			if (allBlocksTable.TryGetValue (new Vector3 (transform.position.x - 1, transform.position.y, transform.position.z), out temp)) {
				closeBlocks.Add (temp);
			}
		} else {
			for(int i = -distance; i < -distance + distance * 2 + 1; i++){
				if (allBlocksTable.TryGetValue(new Vector3(transform.position.x + distance, transform.position.y, transform.position.z + i), out temp)) {
					closeBlocks.Add(temp);
				}
				if (allBlocksTable.TryGetValue(new Vector3(transform.position.x - distance, transform.position.y, transform.position.z + i), out temp)) {
					closeBlocks.Add(temp);
				}
			}
		}

		return closeBlocks;
	}

	IEnumerator ShakeRoutine(){
		shaking = true;
		for (int i = 1; i < 4; i++) {
			List<GameObject> toBeShaken = findWaveBlocks(i);
		
			if (toBeShaken.Count == 0) {
				break;
			}
		
			foreach (GameObject g in toBeShaken){
				g.GetComponent<GroundBehaviour> ().ShakeForTime ();
			}
		
			yield return new WaitForSeconds (0.5f);
		}
		shaking = false;
	}

	public void StartShake(){
		StartCoroutine ("ShakeRoutine");
	}

	private void HandleMovement(){
		//setCurPos (transform.position);
		transform.position = (curState.GetMovement (curPos));
		//setLastPos (curPos.transform.position);
		curPos = transform.position;
	}

//	public void setLastPos(Vector3 pos){
//		GameObject temp;
//		allBlocksTable.TryGetValue (pos, out temp);
//		lastPos = temp;
//	}

//	public void setCurPos(Vector3 pos){
//		GameObject temp;
//		allBlocksTable.TryGetValue (pos, out temp);
//		curPos = temp;
//	}


	void OnTriggerEnter(Collider other){
		if(other.tag == "Player" && Vector3.Distance(other.transform.position, gameObject.transform.position) < 5f && deamDmg){
			//other.gameObject.GetComponent<Controller3D> ().Damage (20);
			//curState = new enemy2Defeat (gameObject);
			Die(other);
		}else if(other.tag == "Player" && (curState as Enemy2Idle != null)){
			curState = new Enemy2Patrol (gameObject);
		}
	}

	public void Die(Collider other){
		if (other.gameObject.tag == "Player") {
			deamDmg = false;
			if (other.gameObject.GetComponent<Controller3D> ().topSide) {
				other.gameObject.GetComponent<Controller3D>().GetVelocity ().SetY (20f);
			}
			else
				other.gameObject.GetComponent<Controller3D>().GetVelocity ().SetY (-20f);			
			//Destroy (gameObject);
			StartCoroutine(DeathDelay());
		}
	}

    IEnumerator DeathDelay()
    {
        source.PlayOneShot(deathClip);
        yield return new WaitForSeconds(0.2f);
        curState = new enemy2Defeat(gameObject);

    }

    void OnTriggerExit(Collider other) {
		if(other.tag == "Player" && (curState as Enemy2Idle == null)){
			transform.localPosition = startPos;
			curState = new Enemy2Idle (gameObject);
		}
	}

	public void taBort(){
		Destroy(gameObject);
	}

	public void reset(){
		transform.localPosition = startPos;
		curPos = transform.position;
		curState = new Enemy2Idle (gameObject);
	}
}
