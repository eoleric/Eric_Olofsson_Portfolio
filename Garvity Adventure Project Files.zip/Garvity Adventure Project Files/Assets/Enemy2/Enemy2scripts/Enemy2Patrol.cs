﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2Patrol : Enemy2State {

	private List<GameObject> closeBlocks;

	private Vector3 walkTo;
	private float headsup;

	// Use this for initialization
	void Start () {
		

	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public Enemy2Patrol(GameObject player): base(player){
		closeBlocks = base.getEnemy ().GetComponent<enemy2> ().findCloseBlocks ();
		walkTo = closeBlocks[Random.Range (0, closeBlocks.Count)].transform.position;
		headsup = Time.time;
	}

	public override Vector3 GetMovement (Vector3 position){
		if (Time.time - headsup > 3f) {
			base.getEnemy ().GetComponent<enemy2> ().curState = new Enemy2Deal (base.getEnemy());
		}
		closeBlocks = base.getEnemy ().GetComponent<enemy2> ().findCloseBlocks ();
		walkTo = closeBlocks [Random.Range (0, closeBlocks.Count)].transform.position;
		return walkTo;
	}



	public override void CalculateShake(){
		if (!base.getEnemy ().GetComponent<enemy2> ().shaking) {
			base.getEnemy ().GetComponent<enemy2> ().StartShake ();
		}
	}
}
