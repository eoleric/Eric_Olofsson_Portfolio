﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2Idle : Enemy2State {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public Enemy2Idle(GameObject player): base(player){

	}

	public override Vector3 GetMovement (Vector3 position){
		return position;
	}

	public override void CalculateShake(){}
}
