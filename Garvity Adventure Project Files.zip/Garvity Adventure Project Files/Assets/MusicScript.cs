﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicScript : MonoBehaviour {

	private AudioSource source;
	public AudioClip[] clips;

	private bool hubPlay = true;
	private bool lvlOnePlay = false;
	private bool bossPlay = false;
	private bool lvlTwoPlay = false;
	private bool lvlThreePlay = false;
	private int musicPlaying = 0;

	private GameManager manager;

	private int levelNumber;

	public int volumeUp = 0;


	// Use this for initialization
	void Start () {

		source = GetComponent<AudioSource> ();
		manager = GetComponentInParent<GameManager> ();

		source.clip = clips [0];
		source.loop = true;
		source.PlayDelayed (8f);
		
	}
	
	// Update is called once per frame
	void Update () {

		if (volumeUp == 1) {
			source.volume = source.volume - Time.deltaTime / 1.5f;
		} else if (volumeUp == 2 && source.volume < 0.7f) {
			source.volume = source.volume + Time.deltaTime / 1.5f;
		}

		levelNumber = manager.newlvl;

		if(levelNumber==1 && musicPlaying!=0 || levelNumber==2 && musicPlaying!=0){
			musicPlaying = 0;
			volumeUp = 1;
			StartCoroutine (musicSwitch (0));
		} 

		if(levelNumber==3 && musicPlaying!=1){
			musicPlaying = 1;
			volumeUp = 1;
			StartCoroutine (musicSwitch (1));
		}

		if(levelNumber==4 && musicPlaying!=2){
			musicPlaying = 2;
			volumeUp = 1;
			StartCoroutine (musicSwitch (2));
		}

		if(levelNumber==5 && musicPlaying!=3){
			musicPlaying = 3;
			volumeUp = 1;
			StartCoroutine (musicSwitch (3));
		}

		if(levelNumber==6 && musicPlaying!=4){
			musicPlaying = 4;
			volumeUp = 1;
			StartCoroutine (musicSwitch (4));
		}
		
	}

	private IEnumerator musicSwitch(int clipIndex){
		yield return new WaitForSeconds (1.5f);
		source.clip = clips [clipIndex];
		source.Play ();
		volumeUp = 2;
		StartCoroutine (volumeSwitch ());
	}

	private IEnumerator volumeSwitch(){
		yield return new WaitForSeconds (1.5f);
		volumeUp = 0;
	}
		



}
