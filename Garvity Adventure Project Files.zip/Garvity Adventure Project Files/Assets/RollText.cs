﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class RollText : MonoBehaviour {

    public bool fadeIn;
    public bool fadeOut;
    public int inDelay;
    public int outDelay;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (fadeIn)
        {
            StartCoroutine("FadeInText");
        }
        if (fadeOut)
        {
            StartCoroutine("FadeOutText");
        }
	}

	IEnumerator FadeInText() {
		yield return new WaitForSeconds (inDelay);
		Text text = GetComponent<Text> ();
		text.color = new Color (text.color.r, text.color.g, text.color.b, text.color.a + (Time.deltaTime / 15f));
		while (text.color.a < 1.0f) {
			text.color = new Color (text.color.r, text.color.g, text.color.b, text.color.a + (Time.deltaTime / 15f));
			yield return null;
		}
	}

    IEnumerator FadeOutText()
    {
        yield return new WaitForSeconds(outDelay);
        Text text = GetComponent<Text>();
        text.color = new Color(text.color.r, text.color.g, text.color.b, text.color.a - (Time.deltaTime / 5f));
        while (text.color.a > 0.0f)
        {
            text.color = new Color(text.color.r, text.color.g, text.color.b, text.color.a - (Time.deltaTime / 5f));
            yield return null;
        }
    }

}
