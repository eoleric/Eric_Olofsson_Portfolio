﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Room : MonoBehaviour
{
    public bool Default;

    private RoomCollider[] _colliders;

    private void Awake()
    {
        _colliders = GetComponentsInChildren<RoomCollider>();
    }

    public void Activate()
    {
        //Spawn enemies
    }
    public void Deactivate()
    {
        //Remove enemies
    }

    public void SetCollidersActive(bool active)
    {
        foreach (RoomCollider coll in _colliders) coll.gameObject.SetActive(active);
    }
}
