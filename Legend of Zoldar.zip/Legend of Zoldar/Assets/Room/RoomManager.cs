﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomManager : MonoBehaviour
{
    private static RoomManager _instance;
    [HideInInspector] public Room ActiveRoom;

    private void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    private void Start()
    {
        Room[] rooms = FindObjectsOfType<Room>();
        foreach (Room room in rooms)
        {
            int layer = room.Default ? LayerMask.NameToLayer("Seen") : LayerMask.NameToLayer("Unseen");
            SetLayerRecursivly(room.gameObject, layer);
            if (room.Default) SetActiveRoom(room, true);
        }
    }
    private void SetLayerRecursivly(GameObject go, int layer)
    {
        go.layer = layer;
        foreach(Transform child in go.transform) SetLayerRecursivly(child.gameObject, layer);
    }

    public static void SetActiveRoom(Room newRoom, bool forceMovement)
    {
        _instance.StartCoroutine(_instance.SetActiveRoomCoroutine(newRoom, forceMovement));
    }
    private IEnumerator SetActiveRoomCoroutine(Room newRoom, bool forceMovement)
    {
        SetLayerRecursivly(newRoom.gameObject, LayerMask.NameToLayer("Seen"));

        Room oldRoom = ActiveRoom;
        newRoom.SetCollidersActive(false);
        ActiveRoom = newRoom;

        
        if (forceMovement)
            CameraMovement.Instance.transform.position = newRoom.transform.position;
        else
            yield return CameraMovement.Instance.MoveToNewRoom(newRoom);

        if (oldRoom == null || oldRoom == newRoom) yield break;
        oldRoom.SetCollidersActive(true);
        SetLayerRecursivly(oldRoom.gameObject, LayerMask.NameToLayer("Unseen"));
        yield return null;
    }
}
