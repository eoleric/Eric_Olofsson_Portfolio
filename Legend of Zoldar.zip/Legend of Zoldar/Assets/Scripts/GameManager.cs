﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("Scenes")]
    public int MinSceneId;
    public int MaxSceneId;
    [Header("UI")]
    public Image FadeOutPanel;
    public float FadeToBlackDuration, FadeBackTime;

    public PlayerController Player;

    private Room _roomToReturnTo;
    private Transform _returnPoint;
    private string _extraRoomName;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        StartCoroutine(LoadAllScenes());
    }
    private IEnumerator LoadAllScenes()
    {
        //SceneManager.LoadScene("Gameplay");
        List<AsyncOperation> operations = new List<AsyncOperation>();

        for(int i = MinSceneId; i <= MaxSceneId; i++) operations.Add(SceneManager.LoadSceneAsync(i, LoadSceneMode.Additive));

        while (true)
        {
            if(operations.Any(o => !o.isDone)) yield return null;
            else break;
        }
    }

    public void LoadExtraRoom(string id, Transform returnPoint, Room room)
    {
        StartCoroutine(LoadExtraRoomCoroutine(id + "ExtraRoom"));
        _roomToReturnTo = room;
        _returnPoint = returnPoint;
        _extraRoomName = id + "ExtraRoom";
    }
    private IEnumerator LoadExtraRoomCoroutine(string sceneName)
    {
        yield return Fade(1.0f, FadeToBlackDuration);
        
        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Additive);
        while (!operation.isDone) yield return null;

        ExtraRoom extraRoom = FindObjectOfType<ExtraRoom>();
        Player.transform.position = extraRoom.PlayerSpawnPosition;
        CameraMovement.Instance.transform.position = extraRoom.CameraPosition;

        yield return Fade(0.0f, FadeBackTime);
    }
    private IEnumerator Fade(float alpha, float duration)
    {
        float t = 0.0f;
        Color startColor = FadeOutPanel.color; startColor.a = 1.0f - alpha;
        Color endColor = startColor; endColor.a = alpha;

        while (t < duration)
        {
            t += Time.deltaTime;
            FadeOutPanel.color = Color.Lerp(startColor, endColor, t / duration);
            yield return null;
        }
    }

    public void ReturnTo()
    {
        StartCoroutine(ReturnToRoomCoroutine());
    }
    private IEnumerator ReturnToRoomCoroutine()
    {
        yield return Fade(1.0f, FadeToBlackDuration);

        Player.transform.position = _returnPoint.position;
        RoomManager.SetActiveRoom(_roomToReturnTo, true);
        SceneManager.UnloadSceneAsync(_extraRoomName);

        yield return Fade(0.0f, FadeBackTime);
    }
	
}
