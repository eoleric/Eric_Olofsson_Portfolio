﻿using UnityEngine;

public static class ControllerHelper
{
    public static RaycastHit2D Move(Controller2D controller, float colliderRadius)
    {
        var deltaTime = Time.deltaTime;
        
        var movement = controller.Velocity.GetVelocity() * deltaTime;
        var hit = Physics2D.CircleCast(controller.transform.position, colliderRadius,
            controller.Velocity.GetVelocity().normalized,
            movement.magnitude + controller.Velocity.CollisionMargin, controller.Velocity.CollisionMask);
        if (hit)
        {
            controller.transform.position = Vector2.MoveTowards(controller.transform.position, hit.centroid,
                Vector2.Distance(controller.transform.position, hit.centroid) - controller.Velocity.CollisionMargin);
            return hit;
        }

        controller.transform.Translate(new Vector3(movement.x, movement.y, 0f));

        return hit;
    }
}