﻿using UnityEngine;

[RequireComponent(typeof(CircleCollider2D))]
public class PlayerController : Controller2D
{
    protected override void SetDefaultState()
    {
        CurrentState = new CharacterStateNormal(this);
        CurrentState.Enter();
    }

    public override void Stun(float time, Vector2 speed)
    {
        SwitchState(new CharacterStateStunned(this, time, speed));
    }

    private void OnCollisionEnter2D(Collision2D coll)
    {
        //Du gick på något
    }
}