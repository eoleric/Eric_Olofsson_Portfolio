﻿using UnityEngine;


public abstract class Controller2D : MonoBehaviour
{
    [SerializeField] private Velocity velocity_;


    public Velocity Velocity
    {
        get { return velocity_; }
    }


    protected CharacterState CurrentState;


    private void Awake()
    {
        SetDefaultState();
    }


    // Use this for initialization
    private void Start()
    {
    }


    // Update is called once per frame
    private void Update()
    {
        var newState = CurrentState.UpdateInput();
        if (newState != null)
        {
            SwitchState(newState);
        }
    }


    private void FixedUpdate()
    {
        var newState = CurrentState.UpdateMovement();
        if (newState != null)
        {
            SwitchState(newState);
        }
    }


    protected void SwitchState(CharacterState state)
    {
        Debug.Log("Switching state from " + CurrentState.GetType() + " to " + state.GetType());
        CurrentState.Exit();
        CurrentState = state;
        CurrentState.Enter();
    }


    protected abstract void SetDefaultState();


    public virtual void Stun(float time, Vector2 speed)
    {
        
    }
}