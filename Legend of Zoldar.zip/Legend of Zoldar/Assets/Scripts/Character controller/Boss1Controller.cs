﻿using System.Collections;
using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
public class Boss1Controller : Controller2D
{
    public float MinMoveTime = 0.5f;
    public float MaxMoveTime = 1f;
    public float MinAttackTime = 0.5f;
    public float MaxAttackTime = 2f;
    public float AttackWaitTime = 0.5f;


    protected override void SetDefaultState()
    {
        CurrentState = new Boss1StateIdle(this);
        CurrentState.Enter();
    }

    public IEnumerator Attack()
    {
        //Open mouth
        yield return new WaitForSeconds(AttackWaitTime);
        //Attack with FIRE!!!!
    }
}