﻿using UnityEngine;

public class CharacterStateNormal : CharacterState
{
    private PlayerController Controller;

    public CharacterStateNormal(PlayerController controller)
    {
        Controller = controller;
    }


    public override void Enter()
    {
    }


    public override void Exit()
    {
    }


    public override CharacterState UpdateInput()
    {
        var input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (input.magnitude > 1f) input.Normalize();
        Controller.Velocity.AccelerateInDirection(input);

        if (Input.GetKeyDown(KeyCode.P))
        {
            return new CharacterStateStunned(Controller, 5f, Vector2.zero);
        }

        return null;
    }


    public override CharacterState UpdateMovement()
    {
        ControllerHelper.Move(Controller, Controller.GetComponent<CircleCollider2D>().radius * Mathf.Max(Controller.transform.lossyScale.x, Controller.transform.lossyScale.y));
        
        return null;
    }
}