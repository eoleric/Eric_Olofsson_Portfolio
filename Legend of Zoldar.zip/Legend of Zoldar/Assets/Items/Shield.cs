﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield {

    private bool Active;

    public void Activate()
    {
        Active = true;
    }
    public void Deactivate()
    {
        Active = false;
    }
	

}
