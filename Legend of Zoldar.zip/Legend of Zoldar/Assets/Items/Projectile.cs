﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour {

    private int damage;
    private Vector2 direction;
    private float speed;
    private string target;
    private int[] deflectDir = { -1, 1 };
    // Update is called once per frame
    public void Update () {
        transform.Translate(new Vector3(direction.x, direction.y, 0f) * speed * Time.deltaTime);
    }

    public void OnSpawn(Vector2 direction, int damage, float speed, string target)
    {
        this.damage = damage;
        this.speed = speed;
        this.direction = direction;
        this.target = target;
    }

    public void Deflect()
    {
        direction *= -1;
        var v = new Vector3(direction.x, direction.y, 0);
        v.x += ((Mathf.Abs(v.x)-1 )* deflectDir[Random.Range(0, deflectDir.Length)]) * Random.Range(0.1f, 0.4f);
        v.y += ((Mathf.Abs(v.y)-1) * deflectDir[Random.Range(0, deflectDir.Length)]) * Random.Range(0.1f, 0.4f);
        direction = v;
        speed /= 4;
        target = "enemy";

    }

  
        
    

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag(target))
        {
            //Let player handle collision
        } else if (collision.CompareTag("Border"))
        {
            Destroy(this.gameObject);
        }
        else { }
    }

    

}
