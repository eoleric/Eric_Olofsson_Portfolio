﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sword : MonoBehaviour{

    private int damage;
    public Projectile projectile;

    public void Upgrade()
    {
        damage *= 2;
    }

    public void Attack(Vector2 direction, bool Beam)
    {
        var origin = direction.normalized;
        origin.x *= 1.5f;
        origin.y *= 1.5f;
        var hit = Physics2D.BoxCastAll(origin, new Vector2(1, 1), 0, Vector2.up);
        foreach(RaycastHit2D other in hit)
        {
            /*if (other.collider.CompareTag("enemy"))
            {
                //do damage
            } */
        }
        if (Beam)
        {
            Swordbeam(direction, origin);
        }
        
    }

    public void Swordbeam(Vector2 direction, Vector2 origin)
    {
        var proj = Instantiate(projectile, origin, Quaternion.identity);
        proj.transform.rotation = this.transform.rotation;
        proj.OnSpawn(direction, damage, 17f, "Enemy");
    }
}
